function U=node_size_effect(Result,u_total,u_corr12,vol00,vol01)
%%
u0=u_corr12{1};
[~, m0] = parseImages(vol00,[128 128 64]);
idx = cell(1,3); idx_u0 = cell(1,3);
for i = 1:3
    idx{i} = m0{i}(1):m0{i}(end); 
    idx_u0{i} = linspace(1,size(u0{1},i),length(idx{i})+1); 
    idx_u0{i} = idx_u0{i}(1:length(idx{i}));
end
[m_u0{2}, m_u0{1}, m_u0{3}] = ndgrid(idx_u0{:});
u_corr = cell(1,3);
for i = 1:3, u_corr{i} = mirt3D_mexinterp(u0{i}, m_u0{1}, m_u0{2}, m_u0{3}); end
%%
Disp=Result{3}-Result{4};
Node=Result{4};
for i=1:size(Node,1)
 Abaqus_disp(i,1)=u_total{2}(Node(i,1),Node(i,2),Node(i,3)); 
 Abaqus_disp(i,2)=u_total{1}(Node(i,1),Node(i,2),Node(i,3));
 Abaqus_disp(i,3)=u_total{3}(Node(i,1),Node(i,2),Node(i,3));
 corr_disp(i,1)=u_corr{2}(Node(i,1),Node(i,2),Node(i,3)); 
 corr_disp(i,2)=u_corr{1}(Node(i,1),Node(i,2),Node(i,3));
 corr_disp(i,3)=u_corr{3}(Node(i,1),Node(i,2),Node(i,3));
end
a=[];b=[];c=[];Actualx=[];Actualy=[];FBVx=[];FBVy=[];corrx=[];corry=[];
x=Result{4}(:,1)';y=Result{4}(:,2)';z=Result{4}(:,3)';
for s=1:length(z)
    if z(s)>75 && z(s)<85
        a=[a,x(s)];b=[b,y(s)];c=[c,z(s)];
        Actualx=[Actualx,Abaqus_disp(s,2)];
        Actualy=[Actualy,Abaqus_disp(s,1)];
        corrx=[corrx,corr_disp(s,2)];
        corry=[corry,corr_disp(s,1)];
        FBVx=[FBVx,Disp(s,2)];
        FBVy=[FBVy,Disp(s,1)];
     end
end
%%
figure
H=imfuse(vol00(:,:,80),vol01(:,:,80),'ColorChannels',[1 2 0]);
image(H)
hold on
scatter(b,a,'*','r')
Q1=quiver(b,a,Actualx,Actualy,'m');
Q2=quiver(b,a,corrx,corry,'g');
Q3=quiver(b,a,FBVx,FBVy,'y');
Q1.AutoScale='off';
Q2.AutoScale='off';
Q3.AutoScale='off';
for tt=1:length(a)
    e=abs(corrx(tt));
    e=round(e,2);
    e=num2str(e);
    t=text(b(tt),a(tt),e);
    t.Color = 'g';
t.FontSize = 6;
    f=abs(Actualx(tt));
    f=round(f,2);
    f=num2str(f);
    t=text(b(tt),a(tt)+2,f);
    t.Color = 'm';
t.FontSize = 6;
    g=abs(FBVx(tt));
    g=round(g,2);
    g=num2str(g);
    t=text(b(tt),a(tt)-2,g);
    t.Color = 'Y';
t.FontSize = 6;
end
FU1= scatteredInterpolant(Node, corr_disp(:,1));
FU2= scatteredInterpolant(Node,corr_disp(:,2));
FU3= scatteredInterpolant(Node,corr_disp(:,3));
for x=1:size(vol00,1)
%     i=i+1;
    for y=1:size(vol00,2)
%         j=j+1;
        for z=1:size(vol00,3)
%             k=k+1;
                U1(x,y,z)=FU1([x y z]);
                U2(x,y,z)=FU2([x y z]);
                U3(x,y,z)=FU3([x y z]);
            
        end
    end
end
U{1}{1}=U1;
U{1}{2}=U2;
U{1}{3}=U3;
end


function varargout = parseImages(varargin)
% pads images and creates meshgrid
I = varargin{1};
sSize = varargin{2};
prePad = sSize/2;
postPad = sSize/2;
sizeI = size(I);
I = padarray(I,prePad,0,'pre');
I = padarray(I,postPad,0,'post');
idx = cell(1,3);
for i = 1:3, idx{i} = (1:1:sizeI(i)) + sSize(i)/2; end
varargout{    1} = I;
varargout{end+1} = idx;

end