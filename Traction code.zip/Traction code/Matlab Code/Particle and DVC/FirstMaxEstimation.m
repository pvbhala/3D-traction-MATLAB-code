function Particle2=FirstMaxEstimation(I)
A=reshape(I,[],1);
abs_max=max(A);
B=I>0.2*abs_max;
I1=I.*B;
CC = bwconncomp(I1);
Particle=[];
width=5;
% for r = 1:CC.NumObjects,
%     index = CC.PixelIdxList{r};
%     Siz(r)=size(index,1);
% end
for r = 1:CC.NumObjects,
    index = CC.PixelIdxList{r};
    Particle=[Particle;precise_location(index,I1)];
end
filter_points=remove_outlier_points(Particle);


Particle2=filter_points;
% for r = 1:size(Particle,1),
%     m=Particle(r,1);n=Particle(r,2); p=Particle(r,3);
%     Check=[size(I1,1)-width,size(I1,2)-width,size(I1,3)-width];
%     if m>Check(1) || n>Check(2)|| p>Check(3)
%         continue;
%     end
%     if m<=width || n<=width|| p<=width
%         continue;
%     end
%     Particle2=[Particle2;m,n,p];
% % %     %         Y=Q(m+(-1:1),n+(-1:1),p+(-1:1));
% % %     %         YY=find(Y);
% % %     %         L(t)=size(YY,1);
% % %     %         U(t,:)=[index(t),L(t)];
% end
% % for rr = 1:size(Particle,1)
% %     Intensity(rr,1)=I(Particle2(rr,1),Particle2(rr,2),Particle2(rr,3));
% % end
% % Particle2=[Particle2,Intensity];
%     if isempty(L)
%         continue;
%     end
%     [~, V]=max(U(:,2));
%     [i1, i2, i3]=ind2sub(size(I1),index(V));
%     Particle(end+1,:)=[i1 i2 i3];
%     L=[];
%     U=[];
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5555555555555555%%%%%%%%%%%%
% for ty=1:size(Particle,1)
%    for  tz=1:size(Particle,1)
%        dis(ty,tz)=norm(Particle(tz,:)-Particle(ty,:));
%    end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5%%%%%
%size(Particle,1)
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 
for f=1:size(Particle2,1)
    I_test=I(Particle2(f,1)+(-width:width),Particle2(f,2)+(-width:width),Particle2(f,3)+(-width:width));
    rc=radialcenter3D(I_test);
    xc(f,1)=(Particle2(f,1)-width)+(rc(1)-1);
    yc(f,1)=(Particle2(f,2)-width)+(rc(2)-1);
    zc(f,1)=(Particle2(f,3)-width)+(rc(3)-1);
%     [xc_fine(f),yc_fine(f),zc_fine(f)]=MLE(I_test,rc(1),rc(2),rc(3));
%     xc_fine(f)=(Particle2(f,1)-width)+(xc_fine(f)-1);
%     yc_fine(f)=(Particle2(f,2)-width)+(yc_fine(f)-1);
%     zc_fine(f)=(Particle2(f,3)-width)+(zc_fine(f)-1);
%     %    [xxc_fine(f),yyc_fine(f),zzc_fine(f),Theta_peeak(f),Theta_bg(f)]=MLE(I_test,width+1,width+1,width+1);
end
Centroid_radial=[xc,yc,zc];
% Centroid_MLE=[xc_fine',yc_fine',zc_fine'];
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 
end


function  [xc_fine ,yc_fine ,zc_fine]=MLE(I_test,xc,yc,zc)
i=1;
A=reshape(I_test,[],1);
theta_peak(i)=max(A);
theta_bg(i)=mode(A);
theta_x(i)=xc;
theta_y(i)=yc;
theta_z(i)=zc;
sigma_x=1.25;
sigma_y=1.11;
sigma_z=1.07;
SIZE=numel(I_test);
error_x=100;
error_y=100;
error_z=100;
error_peak=100;
error_bg=100;
while error_x(end)>0.1 || error_y(end)>0.1 || error_z(end)>0.1 || error_peak(end)>1
    a_theta_x=0;
    a_theta_y=0;
    a_theta_z=0;
    a_theta_peak=0;
    a_theta_bg=0;
    b_theta_x=0;
    b_theta_y=0;
    b_theta_z=0;
    b_theta_peak=0;
    b_theta_bg=0;
    for k=1:SIZE
        [x,y,z]=ind2sub(size(I_test),k);
        [q, u_x, u_xx, u_y, u_yy, u_z, u_zz, u_peak, u_peak_peak, u_bg, u_bg_bg] =Intensity(x,y,z,theta_x(i),theta_y(i),theta_z(i),theta_peak(i),sigma_x,sigma_y,sigma_z);
        n=I_test(x,y,z);
        a_theta_x=a_theta_x+(u_x*((n/q)-1));
        b_theta_x=b_theta_x+(u_xx*((n/q)-1))-u_x^2*(n/q^2);
        
        a_theta_y=a_theta_y+(u_y*((n/q)-1));
        b_theta_y=b_theta_y+(u_yy*((n/q)-1))-u_y^2*(n/q^2);
        
        a_theta_z=a_theta_z+(u_z*((n/q)-1));
        b_theta_z=b_theta_z+(u_zz*((n/q)-1))-u_z^2*(n/q^2);
        
        a_theta_peak=a_theta_peak+(u_peak*((n/q)-1));
        b_theta_peak=b_theta_peak+(u_peak_peak*((n/q)-1))-u_peak^2*(n/q^2);
        
        a_theta_bg=a_theta_bg+(u_bg*((n/q)-1));
        b_theta_bg=b_theta_bg+(u_bg_bg*((n/q)-1))-u_bg^2*(n/q^2);
    end
    i=i+1;
    theta_x(i)=theta_x(i-1)-(a_theta_x/b_theta_x);
    theta_y(i)=theta_y(i-1)-(a_theta_y/b_theta_y);
    theta_z(i)=theta_z(i-1)-(a_theta_z/b_theta_z);
    theta_peak(i)=theta_peak(i-1)-(a_theta_peak/b_theta_peak);
    theta_bg(i)=theta_bg(i-1)-(a_theta_bg/b_theta_bg);
    error_x(i-1)=abs(theta_x(i)-theta_x(i-1));
    error_y(i-1)=abs(theta_y(i)-theta_y(i-1));
    error_z(i-1)=abs(theta_z(i)-theta_z(i-1));
    error_peak(i-1)=abs(theta_peak(i)-theta_peak(i-1));
    error_bg(i-1)=abs(theta_bg(i)-theta_bg(i-1));
end
xc_fine=theta_x(end);
yc_fine=theta_y(end);
zc_fine=theta_z(end);
peak=theta_peak(end);
bg=theta_bg(end);
end


function [q, u_x, u_xx, u_y, u_yy, u_z, u_zz, u_peak, u_peak_peak, u_bg, u_bg_bg] =Intensity(x,y,z,theta_x,theta_y,theta_z,theta_peak,sigma_x,sigma_y,sigma_z)
E_x=0.5*(erf((x-theta_x+0.5)/(2^0.5*sigma_x))-erf((x-theta_x-0.5)/(2^0.5*sigma_x)));
E_y=0.5*(erf((y-theta_y+0.5)/(2^0.5*sigma_y))-erf((y-theta_y-0.5)/(2^0.5*sigma_y)));
E_z=0.5*(erf((z-theta_z+0.5)/(2^0.5*sigma_z))-erf((z-theta_z-0.5)/(2^0.5*sigma_z)));
q=theta_peak*E_x*E_y*E_z;

u_x=(theta_peak/((2*pi)^0.5*sigma_x))*(exp(-(x-theta_x-0.5)^2/(2*sigma_x^2))-exp(-(x-theta_x+0.5)^2/(2*sigma_x^2)))*E_y*E_z;
u_y=(theta_peak/((2*pi)^0.5*sigma_y))*(exp(-(y-theta_y-0.5)^2/(2*sigma_y^2))-exp(-(y-theta_y+0.5)^2/(2*sigma_y^2)))*E_x*E_z;
u_z=(theta_peak/((2*pi)^0.5*sigma_z))*(exp(-(z-theta_z-0.5)^2/(2*sigma_z^2))-exp(-(z-theta_z+0.5)^2/(2*sigma_z^2)))*E_x*E_y;


u_xx=(theta_peak/((2*pi)^0.5*sigma_x^3))*((x-theta_x-0.5)*exp(-(x-theta_x-0.5)^2/(2*sigma_x^2))-(x-theta_x+0.5)*exp(-(x-theta_x+0.5)^2/(2*sigma_x^2)))*E_y*E_z;
u_yy=(theta_peak/((2*pi)^0.5*sigma_y^3))*((y-theta_y-0.5)*exp(-(y-theta_y-0.5)^2/(2*sigma_y^2))-(y-theta_y+0.5)*exp(-(y-theta_y+0.5)^2/(2*sigma_y^2)))*E_x*E_z;
u_zz=(theta_peak/((2*pi)^0.5*sigma_z^3))*((z-theta_z-0.5)*exp(-(z-theta_z-0.5)^2/(2*sigma_z^2))-(z-theta_z+0.5)*exp(-(z-theta_z+0.5)^2/(2*sigma_z^2)))*E_x*E_y;

u_peak=E_x*E_y*E_z;
u_peak_peak=0;

u_bg=1;
u_bg_bg=0;

end





