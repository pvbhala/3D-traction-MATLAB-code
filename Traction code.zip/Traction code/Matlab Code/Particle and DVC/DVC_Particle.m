%%
function Final_last_Result=DVC_Particle(Output,Particle3)
Particle11=Output{1};
Particle2=Output{2};
Particle1=Output{3};
t=0;
s=0;
for i=1:size(Particle1,1)
    Neibor_min=Finding_Neighbor_one(Particle1(i,:),Particle3,3,1);
    if size(Neibor_min,2)==3
        Result{1}(t+1,:)=Particle1(i,:);
        Result{2}(t+1,:)=Particle11(i,:);
        Result{3}(t+1,:)=Neibor_min(1,:);
        Result{4}(t+1,:)=Particle2(i,:);
        t=t+1;
        continue;
    else
        other_Particle1(s+1,:)=Particle1(i,:);
        other_Particle2(s+1,:)=Particle2(i,:);
        other_Particle11(s+1,:)=Particle11(i,:);
        s=s+1;
    end
%     else
%         Neibor11=Finding_Neighbor_one(Particle1(i,:),Particle1,3,0);
%         Vector11=Make_vector(Particle1(i,:), Neibor11,3);
%         for m=1:3
%             Neibor22_in_2(1,3*3*(m-1)+1:3*3*m)=Finding_Neighbor_one(Neibor_min(1,3*m-2:3*m),Particle3,3,0);
%         end
%         Vector22=Make_vector2(Neibor_min, Neibor22_in_2,3,3);
%         for m=1:3
%             Vector2_column=Vector22(1,3*3*(m-1)+1:3*3*m);
%             Similarity(1,m)=compare(Vector11,Vector2_column,3,3);
%         end
%         X=Similarity(1,:);
%         [~, index]=min(X);
%         Result{1}(i,:)=Particle1(i,:);
%         Result{2}(i,:)=Particle11(i,:);
%         Result{3}(i,:)=Neibor_min(1,3*index-2:3*index);
end
aa=[];
for m=1:size(Particle3,1)
    for n=1:size(Result{3},1)
        if norm(Result{3}(n,:)-Particle3(m,:))==0
            Particle3(m,:)=[0 0 0];
            break;
        end
    end
end
    Particle3( ~any(Particle3,2), : ) = [];
    other_Particle3=Particle3;
    %Result_Plus_REEESult=Second_filter(other_Particle1,other_Particle3,other_Particle11,other_Particle2,Result);
    Final_Result=Filter(Result,3,2,3);
    Final_last_Result=Filter(Final_Result,4,3,4);
end


%%
function Neibor_min=Finding_Neighbor_one(bead,Particles,Requested_neighbor,Y)
Number=size(Particles,1);
Search=10;%pixel
Counter=0;
accept=0;
Neighbor=[];
i=bead(1,1);
j=bead(1,2);
k=bead(1,3);
while accept==0
    for m=1:Number
        if Y==0
            if norm(bead-Particles(m,:))<1e-3
                continue;
            end
        end
        if Particles(m,1)<i+Search && Particles(m,1)>i-Search && Particles(m,2)<j+Search && Particles(m,2)>j-Search && Particles(m,3)<k+Search && Particles(m,3)>k-Search
            Tt=Particles(m,:);
            Neighbor(Counter+1,:)=Tt;
            Counter=Counter+1;
        end
        
    end
    if Counter>=Requested_neighbor
        Ss=Least_distance(bead,Neighbor,Requested_neighbor,Y);
        Neibor_min(1,:)=Ss;
        accept=1;
    else
        Search=Search*2;
        Counter=0;
        Neighbor=[];
    end
end
end
%%
function Neibor_min=Least_distance(Particle,Neighbor,Requested_neighbor,Y)
Neibor_min=[];
n=size(Neighbor,1);
for i=1:n
    a(i)=(Neighbor(i,1)-Particle(1,1))^2+(Neighbor(i,2)-Particle(1,2))^2+(Neighbor(i,3)-Particle(1,3))^2;
end
[b, index]=sort(a);
if Y==1
    if norm(Neighbor(index(1),1:2)-Particle(1,1:2))<2 && (Neighbor(index(1),3)-Particle(1,3))<2
        Neibor_min=Neighbor(index(1),:);
    elseif b(2)>7*b(1)
        Neibor_min=Neighbor(index(1),:);
    else
        for m=1:Requested_neighbor
            Neibor_min=[Neibor_min,Neighbor(index(m),:)];
        end
    end
else
    for m=1:Requested_neighbor
        Neibor_min=[Neibor_min,Neighbor(index(m),:)];
    end
end
end

function Vector=Make_vector(particle, neighbor,Requested_neighbor)
%%
Reference = repmat(particle,[1 Requested_neighbor]);
Vector=neighbor-Reference;
end
%%
function Vector_relaxed=Make_vector2(Candidate_in_relax, Neibor_relax,Requested_neighbor1,Requested_neighbor2)
Reference=[];
for m=1:Requested_neighbor1
    a=Candidate_in_relax(1,3*m-2:3*m);
    b = repmat(a,[1 Requested_neighbor2]);
    Reference=[Reference,b];
end
Vector_relaxed=Neibor_relax-Reference;
end
%%
function output=compare (Vector1,Vector2,Requested_neighbor1,Requested_neighbor2)
for m=1:Requested_neighbor1
    Vector11(m,:)=Vector1(1,3*m-2:3*m);
end
for m=1:Requested_neighbor2
    Vector22(m,:)=Vector2(1,3*m-2:3*m);
end
t=1:Requested_neighbor2;
tt=perms(t);
for i=1:size(tt,1)
    for j=1:Requested_neighbor1
        u=Vector11(j,:);
        v=Vector22(tt(i,j),:);
        Angle=acos(dot(u, v) / (norm(u) * norm(v)));
        if Angle>=0.5*pi
            similarity(i,j)=inf;
        else
            similarity(i,j)=((norm(u)/norm(v))+(norm(v)/norm(u))-2)*((1-cos(Angle))/cos(Angle));
        end
    end
end
for k=1:size(tt,1)
    Final_similarity(k,1)=sum(similarity(k,:));
end
output=min(Final_similarity(:,1));
end
