function [Final_last_Result]=FIDVC_Revised(uu,vol00,vol01)
u0=uu{1};
[I, m0] = parseImages(vol00,[128 128 64]);
idx = cell(1,3); idx_u0 = cell(1,3);
for i = 1:3
    idx{i} = m0{i}(1):m0{i}(end); 
    idx_u0{i} = linspace(1,size(u0{1},i),length(idx{i})+1); 
    idx_u0{i} = idx_u0{i}(1:length(idx{i}));

end
[m_u0{2}, m_u0{1}, m_u0{3}] = ndgrid(idx_u0{:});
[m{2}, m{1}, m{3}] = ndgrid(idx{:});
u = cell(1,3);
for i = 1:3, u{i} = mirt3D_mexinterp(u0{i}, m_u0{1}, m_u0{2}, m_u0{3}); end
mForward = cellfun(@(x,y) x - y, m, u, 'UniformOutput',false);
volcorr = mirt3D_mexinterp(I,  mForward{1}, mForward{2}, mForward{3});
Particle3=FirstMaxEstimation(vol01);
Particle2=FirstMaxEstimation(vol00);
Particle1=FirstMaxEstimation(volcorr);
Particle11=AddDispParticle(Particle2,u);
Output=ComparePart(Particle1,Particle11,Particle2);
Final_last_Result=DVC_Particle(Output,Particle3);
a=[];b=[];c=[];A=[];B=[];C=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%% visualization %%%%%%%%%%%%%%%%%%%%%%%
H=imfuse(vol00(:,:,80),vol01(:,:,80),'ColorChannels',[1 2 0]);
image(H)
x=Final_last_Result{4}(:,1)';y=Final_last_Result{4}(:,2)';z=Final_last_Result{4}(:,3)';
X=Final_last_Result{3}(:,1)';Y=Final_last_Result{3}(:,2)';Z=Final_last_Result{3}(:,3)';
Disp=Final_last_Result{3}-Final_last_Result{4};
for s=1:length(z)
    if z(s)>75 && z(s)<85
        a=[a,x(s)];b=[b,y(s)];c=[c,z(s)];
        A=[A,X(s)];B=[B,Y(s)];C=[C,Z(s)];
    end
end
u1=A-a;u2=B-b;u3=C-c;
hold on
quiver(b,a,u2,u1)
scatter(b,a,'*','r')
scatter(B,A,'*','b')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%getting continouous displacement field %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FU1= scatteredInterpolant(Final_last_Result{4},Disp(:,2));
% FU2= scatteredInterpolant(Final_last_Result{4},Disp(:,1));
% FU3= scatteredInterpolant(Final_last_Result{4},Disp(:,3));
% for x=1:size(vol00,1)
% %     i=i+1;
%     for y=1:size(vol00,2)
% %         j=j+1;
%         for z=1:size(vol00,3)
% %             k=k+1;
%                 U1(x,y,z)=FU1([x y z]);
%                 U2(x,y,z)=FU2([x y z]);
%                 U3(x,y,z)=FU3([x y z]);
%             
%         end
%     end
% end
% U{1}{1}=U1;
% U{1}{2}=U2;
% U{1}{3}=U3;
end

function varargout = parseImages(varargin)
% pads images and creates meshgrid
I = varargin{1};
sSize = varargin{2};
prePad = sSize/2;
postPad = sSize/2;
sizeI = size(I);
I = padarray(I,prePad,0,'pre');
I = padarray(I,postPad,0,'post');
idx = cell(1,3);
for i = 1:3, idx{i} = (1:1:sizeI(i)) + sSize(i)/2; end
varargout{    1} = I;
varargout{end+1} = idx;

end