function Particle11=AddDispParticle(Particle2,u22)
for m=1:size (Particle2,1)
    a=Particle2(m,1);b=Particle2(m,2);c=Particle2(m,3);
    j=u22{1}(a,b,c);
    i=u22{2}(a,b,c);
    k=u22{3}(a,b,c);
    Particle11(m,:)=[Particle2(m,1)+i,Particle2(m,2)+j,Particle2(m,3)+k];
end
end