function Result_filter=Filter(Result,R1,R2,Y)
Result_filter=Result;
b=[];
for i=1:size(Result{R1},1)
    C=1;
    F=[];
    for K=1:size(b,2)
        if b(K)==i
            C=0;
        end
    end
    if C==0
        continue;
    end
    for j=1:size(Result{R1},1)
        if i==j
            continue;
        end
        if norm(Result{R1}(i,:)-Result{R1}(j,:))<0.01
            F=[F,j];
        end
    end
    F=[F,i];
    Output=filtering(F,Result,R1,R2,Y);
    for J=1:size(Output,2)
        Result_filter{1}(Output(J),:)=[0 0 0];
        Result_filter{2}(Output(J),:)=[0 0 0];
        Result_filter{3}(Output(J),:)=[0 0 0];
        Result_filter{4}(Output(J),:)=[0 0 0];
    end
    b=[b,F];
end
Result_filter{1}( ~any(Result_filter{1},2), : ) = [];
Result_filter{2}( ~any(Result_filter{2},2), : ) = [];
Result_filter{3}( ~any(Result_filter{3},2), : ) = [];
Result_filter{4}( ~any(Result_filter{4},2), : ) = [];
end


function Output=filtering(F,Result,R1,R2,Y)
if Y==3
    Vectors=Result{R1}-Result{R2};
[~,Vector_min]=Finding_Neighbor_one(Result{R1}(F(1),:),Result{R2},Vectors,4);
end
if Y==4
    Vectors=Result{R2}-Result{R1};
[~,Vector_min]=Finding_Neighbor_one(Result{R1}(F(1),:),Result{R1},Vectors,4);    
end
for H=1:size(F,2)
    for V=1:size(Vector_min,1)
        u=Vectors(F(H),:);
        v=Vector_min(V,:);
        Angle=acos(dot(u, v) / (norm(u) * norm(v)));
        if Angle>=0.5*pi
            similarity(H,V)=inf;
        else
            similarity(H,V)=((norm(u)/norm(v))+(norm(v)/norm(u))-2)*((1-cos(Angle))/cos(Angle));
        end
    end
end
for k=1:size(F,2)
    Final_similarity(k,1)=sum(similarity(k,:));
end
[~,INDEX]=min(Final_similarity(:,1));
F(INDEX)=[];
Output=F;
end

function [Neibor_min,Vector_min]=Finding_Neighbor_one(bead,Particles,Vectors,Requested_neighbor)
Number=size(Particles,1);
Search=10;%pixel
Counter=0;
accept=0;
Neighbor=[];
i=bead(1,1);
j=bead(1,2);
k=bead(1,3);
while accept==0
    for m=1:Number
        if norm(bead(1,:)-Particles(m,:))<1e-3
            continue
        end
        if Particles(m,1)<i+Search && Particles(m,1)>i-Search && Particles(m,2)<j+Search && Particles(m,2)>j-Search && Particles(m,3)<k+Search && Particles(m,3)>k-Search
            Tt=Particles(m,:);
            Vv=Vectors(m,:);
            Neighbor(Counter+1,:)=Tt;
            Vector_Neighbor(Counter+1,:)=Vv;
            Counter=Counter+1;
        end
        
    end
    if Counter>=Requested_neighbor
        [Neibor_min,Vector_min]=Least_distance(bead,Neighbor,Vector_Neighbor,4);
        accept=1;
    else
        Search=Search*2;
        Counter=0;
        Neighbor=[];
    end
end
end

function [Neibor_min,Vector_min]=Least_distance(Particle,Neighbor,Vector_Neighbor,Requested_neighbor)
Neibor_min=[];
Vector_min=[];
n=size(Neighbor,1);
for i=1:n
    a(i)=(Neighbor(i,1)-Particle(1,1))^2+(Neighbor(i,2)-Particle(1,2))^2+(Neighbor(i,3)-Particle(1,3))^2;
end
[~, index]=sort(a);
for m=1:Requested_neighbor
    Neibor_min=[Neibor_min;Neighbor(index(m),:)];
    Vector_min=[Vector_min;Vector_Neighbor(index(m),:)];
end
end