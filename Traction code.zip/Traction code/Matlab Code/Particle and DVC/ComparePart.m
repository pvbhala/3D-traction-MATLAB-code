function Output=ComparePart(Particle1,Particle11,Particle2)
k=0;
for i=1:size(Particle1,1)
    for j=1:size(Particle11,1)
        b(j)=norm(Particle1(i,:)-Particle11(j,:));
    end
    [b, index]=sort(b,'ascend');
    a(i,:)=b;
    if b(1)<2
        Output{1}(k+1,:)=Particle11(index(1),:);
        Output{2}(k+1,:)=Particle2(index(1),:);
        Output{3}(k+1,:)=Particle1(i,:);
    k=k+1;
    end
    b=[];
end
end