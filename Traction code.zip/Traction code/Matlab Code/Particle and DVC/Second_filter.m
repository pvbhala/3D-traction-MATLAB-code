function Result_Plus_REEESult=Second_filter(other_Particle1,other_Particle3,other_Particle11,other_Particle2,Result)
Particle1=Result{1};
Particle3=Result{3};
DIS=Result{3}-Result{1};
T=1;
for i=1:size(other_Particle1,1)
    Radius=0;
    Vector1=[];
    Vector2=[0 0 0];
    [~, Neibor_Vector]=Finding_Neighbor_one(other_Particle1(i,:),Particle1,DIS,3,0);
    for m=1:3
        Vector1=[Vector1;Neibor_Vector(1,3*(m-1)+1:3*m)];
        Radius=Radius+norm(Neibor_Vector(1,3*(m-1)+1:3*m));
    end
    Radius=Radius/3;
    Search_Radius_xy=2*Radius;
    Search_Radius_z=5*Radius;
    Neighbor=Finding_Shrink_Neighbor(other_Particle1(i,:),other_Particle3,Search_Radius_xy,Search_Radius_z);
    if norm(Neighbor)==0
        continue;
    end
    for m=1:size(Neighbor,1)
        Vector2(m,:)=Neighbor(m,:)-other_Particle1(i,:);
    end
    [output,index]=compare(Vector1,Vector2);
    if output==inf
        continue;
    end
    REEESult{1}(T,:)=other_Particle1(i,:);
    REEESult{2}(T,:)=other_Particle11(i,:);
    REEESult{3}(T,:)=Neighbor(index,:);
    REEESult{4}(T,:)=other_Particle2(i,:);
    T=T+1;
end
Result_Plus_REEESult{1}=[Result{1};REEESult{1}];
Result_Plus_REEESult{2}=[Result{2};REEESult{2}];
Result_Plus_REEESult{3}=[Result{3};REEESult{3}];
Result_Plus_REEESult{4}=[Result{4};REEESult{4}];
end

function Neighbor=Finding_Shrink_Neighbor(bead,Particles,Search_Radius_xy,Search_Radius_z)
Number=size(Particles,1);
Counter=0;
accept=0;
Neighbor=[];
i=bead(1,1);
j=bead(1,2);
k=bead(1,3);
for m=1:Number
    if Particles(m,1)<i+Search_Radius_xy && Particles(m,1)>i-Search_Radius_xy && Particles(m,2)<j+Search_Radius_xy && Particles(m,2)>j-Search_Radius_xy && Particles(m,3)<k+Search_Radius_z && Particles(m,3)>k-Search_Radius_z
        Tt=Particles(m,:);
        Neighbor(Counter+1,:)=Tt;
        Counter=Counter+1;
    end
end
if Counter==0;
    Neighbor=[0 0 0];
end
end





function [Neibor_min, Neibor_vec]=Finding_Neighbor_one(bead,Particles,DIS,Requested_neighbor,Y)
Number=size(Particles,1);
Search=10;%pixel
Counter=0;
accept=0;
Neighbor=[];
i=bead(1,1);
j=bead(1,2);
k=bead(1,3);
while accept==0
    for m=1:Number
        if Y==0
            if norm(bead-Particles(m,:))<1e-3
                continue;
            end
        end
        if Particles(m,1)<i+Search && Particles(m,1)>i-Search && Particles(m,2)<j+Search && Particles(m,2)>j-Search && Particles(m,3)<k+Search && Particles(m,3)>k-Search
            Tt=Particles(m,:);
            Vv=DIS(m,:);
            Neighbor(Counter+1,:)=Tt;
            Vec_Neighbor(Counter+1,:)=Vv;
            Counter=Counter+1;
        end
        
    end
    if Counter>=Requested_neighbor
        [Neibor_min, Neibor_vec]=Least_distance(bead,Neighbor, Vec_Neighbor,Requested_neighbor,Y);
        accept=1;
    else
        Search=Search*2;
        Counter=0;
        Neighbor=[];
    end
end
end
%%
function [Neibor_min, Neibor_vec]=Least_distance(Particle,Neighbor,Vec_Neighbor,Requested_neighbor,Y)
Neibor_min=[];
Neibor_vec=[];
n=size(Neighbor,1);
for i=1:n
    a(i)=(Neighbor(i,1)-Particle(1,1))^2+(Neighbor(i,2)-Particle(1,2))^2+(Neighbor(i,3)-Particle(1,3))^2;
end
[b, index]=sort(a);
if Y==1
    if norm(Neighbor(index(1),1:2)-Particle(1,1:2))<3 && (Neighbor(index(1),3)-Particle(1,3))<5
        Neibor_min=Neighbor(index(1),:);
    elseif b(2)>4*b(1)
        Neibor_min=Neighbor(index(1),:);
    else
        for m=1:Requested_neighbor
            Neibor_min=[Neibor_min,Neighbor(index(m),:)];
        end
    end
else
    for m=1:Requested_neighbor
        Neibor_min=[Neibor_min,Neighbor(index(m),:)];
        Neibor_vec=[Neibor_vec,Vec_Neighbor(index(m),:)];
        
    end
end
end


%%
function [output,index]=compare(Vector1,Vector2)
for i=1:size(Vector2,1)
    for j=1:size(Vector1,1)
        u=Vector2(i,:);
        v=Vector1(j,:);
        Angle=acos(dot(u, v) / (norm(u) * norm(v)));
        if Angle>=0.5*pi
            similarity(i,j)=inf;
        else
            similarity(i,j)=((norm(u)/norm(v))+(norm(v)/norm(u))-2)*((1-cos(Angle))/cos(Angle));
        end
    end
end
for k=1:size(Vector2,1)
    Final_similarity(k,1)=sum(similarity(k,:));
end
[output,index]=min(Final_similarity(:,1));
end