a=size(vol00);
b=size (vol01);
ref=[288 288 128];
A=floor((ref-a)/2);
B=ceil((ref-a)/2);
C=floor((ref-b)/2);
D=ceil((ref-b)/2);
vol00=cat(1,vol00,zeros(A(1),a(2),a(3)));
vol00=cat(1,zeros(B(1),a(2),a(3)),vol00);
vol00=cat(2,vol00,zeros(288,A(2),a(3)));
vol00=cat(2,zeros(288,B(2),a(3)),vol00);
if A(3)>0
    vol00=cat(3,vol00,zeros(288,288,A(3)));
    vol00=cat(3,zeros(288,288,B(3)),vol00);
else
    vol00(:,:,1:-A(3))=[];
    vol00(:,:,end+B(3)+1:end)=[];
end
vol01=cat(1,vol01,zeros(C(1),b(2),b(3)));
vol01=cat(1,zeros(D(1),b(2),b(3)),vol01);
vol01=cat(2,vol01,zeros(288,C(2),b(3)));
vol01=cat(2,zeros(288,D(2),b(3)),vol01);
if C(3)>0
    vol01=cat(3,vol01,zeros(288,288,C(3)));
    vol01=cat(3,zeros(288,288,D(3)),vol01);
else
    vol01(:,:,1:-C(3))=[];
    vol01(:,:,end+D(3)+1:end)=[];
end