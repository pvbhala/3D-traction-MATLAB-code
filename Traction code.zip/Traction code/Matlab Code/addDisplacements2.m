function [u, du, cc] = addDisplacements2(u0,du0,cc0,m0,dm)
% u = addDisplacements(u,thr,epsilon) removes outliers using the universal
% outlier test based on
%
% J. Westerweel and F. Scarano. Universal outlier detection for PIV data.
% Exp. Fluids, 39(6):1096{1100, August 2005. doi: 10.1007/s00348-005-0016-6
%
% INPUTS
% -------------------------------------------------------------------------
%   u0: displacement field vector defined at every meshgrid point with
%      spacing dm. Format: cell array, each containing a 3D matrix
%         (components in x,y,z)
%         u0{1} = displacement in x-direction
%         u0{2} = displacement in y-direction
%         u0{3} = displacement in z-direction
%         u0{4} = magnitude
%   thr: theshold for passing residiual (default = 2)
%   epsilon: fluctuation level due to cross-correlation (default = 0.1)
%
% OUTPUTS
% -------------------------------------------------------------------------
%   u: cell containing the displacement field with outliers removed
%   normFluctValues: normalized fluctuation values based on the universal
%   outier test.
%
% NOTES
% -------------------------------------------------------------------------
% needs medFilt3 and John D'Errico's inpaint_nans3
% (http://www.mathworks.com/matlabcentral/fileexchange/4551-inpaint-nans)function.
%
% If used please cite:
% Bar-Kochba E., Toyjanova J., Andrews E., Kim K., Franck C. (2014) A fast
% iterative digital volume correlation algorithm for large deformations.
% Experimental Mechanics. doi: 10.1007/s11340-014-9874-2
[index,du0] = erfan1(du0);

for i = 1:3, du0{i} = inpaint_nans3(du0{i}); end % remove NaNs if present

[Node, Disp]=erfan2(du0,index,m0);

idx = cell(1,3);
for i = 1:3, idx{i} = m0{i}(1):dm:m0{i}(end); end % construct new meshgrid

% [m0_{1}, m0_{2}, m0_{3}] = ndgrid(m0{1},m0{2},m0{3});
[m{1}, m{2}, m{3}] = ndgrid(idx{1},idx{2},idx{3});
% sample to desired mesh spacing

c = cell(1,3);
if isempty(Node)
    c{1}=zeros(size(m{1}));
    c{2}=zeros(size(m{1}));
    c{3}=zeros(size(m{1}));
else
    FU1= scatteredInterpolant(Node(:,1:3), Disp(:,1),'linear','nearest');
    FU2= scatteredInterpolant(Node(:,1:3), Disp(:,2),'linear','nearest');
    FU3= scatteredInterpolant(Node(:,1:3), Disp(:,3),'linear','nearest');
    for i = 1:numel(m{1})
        c{1}(i) = FU1([m{1}(i),m{2}(i),m{3}(i)]);
        c{2}(i) = FU2([m{1}(i),m{2}(i),m{3}(i)]);
        c{3}(i) = FU3([m{1}(i),m{2}(i),m{3}(i)]);
    end
end
du{1}=reshape(c{1},size(m{1}));
du{2}=reshape(c{2},size(m{1}));
du{3}=reshape(c{3},size(m{1}));
cc=du;
% F = griddedInterpolant(m0_{1}, m0_{2}, m0_{3}, cc0, 'linear');
% cc = F(m{1},m{2},m{3});

if  sum(cellfun(@numel, u0)) == 3, u = du; % on first iteration u = du
else u = cellfun(@plus,u0,du,'UniformOutput', 0); % else u^(k) = sum(u^(k-1)) + du (see eq. 7)
end

end


function [index,DU] = erfan1(du)
SizeU=size(du{1});
A=zeros(SizeU);B=zeros(SizeU);C=zeros(SizeU);H=ones(SizeU);
A(find(du{1}))=1;
B(find(du{2}))=1;
C(find(du{3}))=1;
A=~A;
B=~B;
C=~C;
D=A.*B.*C;
H(find(D))=nan;
Du{1}=du{1}+H;
R=isnan(Du{1});
CC = bwconncomp(R);
for r = 1:CC.NumObjects,
    L(r) = length(CC.PixelIdxList{r});
end
[~, e]=max(L);
index=CC.PixelIdxList{e};
DU=du;
DU{1}(index)=0;
DU{2}(index)=0;
DU{3}(index)=0;
DU{1}=DU{1}-ones(size(DU{1}));
end

function [Node, Disp]=erfan2(du,index,m0)
SizeU= du{1};
LENGTH=numel(SizeU);
A=1:LENGTH;
B=setdiff(A,index);
% [i,j,k]=ind2sub(SizeU,B);
[m0_{1}, m0_{2}, m0_{3}] = ndgrid(m0{1},m0{2},m0{3});
i=m0_{1}(B);j=m0_{2}(B);k=m0_{3}(B);
Disp=[du{1}(B'),du{2}(B'),du{3}(B')];
Node=[i',j',k'];
end


