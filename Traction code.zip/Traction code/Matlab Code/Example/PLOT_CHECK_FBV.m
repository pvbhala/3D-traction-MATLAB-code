% x=Centroid_MLE1(:,1);y=Centroid_MLE1(:,2);z=Centroid_MLE1(:,3);
% a=Result-Centroid_MLE1;
% quiver3(x,y,z,u,v,w)
% a=[];
% K=Final_Result{3}-Final_Result{1};
% K0=Final_Result{3}-Final_Result{4};
% N1=size(Particle11,1);
% N2=size(Particle1,1);
N3=size(Particle2,1);
N4=size(Particle3,1);
% N5=size(Final_Result{2},1);
% N6=size(Final_Result{3},1);
% N7=size(Final_Result{4},1);
x1=[];y1=[];z1=[];
x2=[];y2=[];z2=[];
x3=[];y3=[];z3=[];
x4=[];y4=[];z4=[];
x5=[];y5=[];z5=[];
x6=[];y6=[];z6=[];
x7=[];y7=[];z7=[];
u7=[];v7=[];w7=[];
u5=[];v5=[];
a=90;b=30;
% for i=1:N1
%     if Particle11(i,3)<=a && Particle11(i,3)>=b
%         x1=[x1,Particle11(i,1)];y1=[y1,Particle11(i,2)];z1=[z1,Particle11(i,3)];
%        
%     end
% end
% for i=1:N2
%     if Particle1(i,3)<=a && Particle1(i,3)>=b
%         x2=[x2,Particle1(i,1)];y2=[y2,Particle1(i,2)];z2=[z2,Particle1(i,3)];
%         end
% end
for i=1:N3
    if Particle2(i,3)<=a && Particle2(i,3)>=b
        x3=[x3,Particle2(i,1)];y3=[y3,Particle2(i,2)];z3=[z3,Particle2(i,3)];
        end
end
for i=1:N4
    if Particle3(i,3)<=a && Particle3(i,3)>=b
        x4=[x4,Particle3(i,1)];y4=[y4,Particle3(i,2)];z4=[z4,Particle3(i,3)];
        end
end
% for i=1:N5
%     if Final_Result{1}(i,3)<=a && Final_Result{1}(i,3)>=b
%         x5=[x5,Final_Result{1}(i,1)];y5=[y5,Final_Result{1}(i,2)];z5=[z5,Final_Result{1}(i,3)];
%         u5=[u5,K(i,1)];v5=[v5,K(i,2)];
%  end
% end
% for i=1:N6
%     if Final_Result{3}(i,3)<=a && Final_Result{3}(i,3)>=b
%         x6=[x6,Final_Result{3}(i,1)];y6=[y6,Final_Result{3}(i,2)];z6=[z6,Final_Result{3}(i,3)];
%         end
% end
% for i=1:N7
%     if Final_Result{4}(i,3)<=a && Final_Result{4}(i,3)>=b
%         x7=[x7,Final_Result{4}(i,1)];y7=[y7,Final_Result{4}(i,2)];z7=[z7,Final_Result{4}(i,3)];
%         u7=[u7,K0(i,1)];v7=[v7,K0(i,2)];w7=[w7,K0(i,3)];
%  end
% end

figure(1)
% C=imfuse(I22{3}(:,:,55),I22{2}(:,:,55),'ColorChannels',[1 2 0]);
C=imfuse(I0{1}(:,:,64),I0{2}(:,:,64),'ColorChannels',[1 2 0]);
image(C)
% image(Tensile2_Cropped_deconv(:,:,45))
hold on
scatter(y3,x3,'b','linewidth',2)
scatter(y4,x4,'v','linewidth',2)
% scatter(y2,x2,'*','linewidth',3)

% scatter(y6,x6,'O','linewidth',3)
% quiver(y5,x5,v5,u5,0,'linewidth',0.5)
quiver(y7,x7,v7,u7,0,'linewidth',0.5)




% function PLOT_CHECK_FBV
% (particle_stressed,Result,Tensile1_deconv,Tensile2_deconv)
% particle_stressed(:,3)=round(particle_stressed(:,3));
% Result(:,3)=round(Result(:,3));
% N=size(particle_stressed,1);
% A1=(particle_stressed(:,3))';
% A2=(Result(:,3))';
% [A11, index1]=sort(A1);
% [A22, index2]=sort(A2);
% for i=1:N
%     particle_stressed_revised(i,:)=[particle_stressed(index1(i),1:2),A11(i)];
%     Result_revised(i,:)=[Result(index2(i),1:2),A22(i)];
% end
%
% for j=1:N
%     for k=1:N
%         if particle_stressed_revised(k,3)==particle_stressed_revised(j,3)
%         else
%             a[end]=k
%         end
%         if Result_revised(k,3)==particle_stressed_revised(j,3)
%         else
%             a[end]=k
%         end