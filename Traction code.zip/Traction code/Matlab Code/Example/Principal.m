function [principal_strains,principal_strains_dir]=Principal(Eij,Sij,uu,dm,Pixel_size,vol00)

Particle2=FirstMaxEstimation(vol00);
Particle2=[Particle2(:,2),Particle2(:,1),Particle2(:,3)];
Particle2=[Pixel_size(1).*Particle2(:,1),Pixel_size(2).*Particle2(:,2),Pixel_size(3).*Particle2(:,3)];
Particle22=Particle2;

Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
Surf_remove=unique(Surf(:));
for G=1:size(Surf_remove,1)
    Particle22(Surf_remove(G,1),:)=[0 0 0];
end
Particle22( ~any(Particle22,2), : ) = [];

for layer=1:2
    Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
    [Surf_fine, Particle_fine]=finer(Surf,Particle22);
    [Surf_fine, Particle_fine]=finer(Surf_fine,Particle_fine);
    [Surface, ~, ~, ~]=get_surf_normal_grid(Surf_fine,Particle_fine,layer);
    Surf_remove=unique(Surf(:));
    for G=1:size(Surf_remove,1)
        Particle22(Surf_remove(G,1),:)=[0 0 0];
    end
    Particle22( ~any(Particle22,2), : ) = [];
end
Surf_grid=Surface{2};
i_min=floor(min(Surf_grid(:,2))./Pixel_size(2));j_min=floor(min(Surf_grid(:,1))./Pixel_size(1));k_min=floor(min(Surf_grid(:,3))./Pixel_size(3));
i_max=ceil(max(Surf_grid(:,2))./Pixel_size(2));j_max=ceil(max(Surf_grid(:,1))./Pixel_size(1));k_max=ceil(max(Surf_grid(:,3))./Pixel_size(3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cnt=0;
stepx=8;
stepz=4;
%figure(2)
for i=i_min:stepx:i_max
    for j=j_min:stepx:j_max
        for k=k_min:stepz:k_max
            Particle_inside=[Pixel_size(1).*j,Pixel_size(2).*i,Pixel_size(3).*k];
            if inhull(Particle_inside,Surf_grid)
                hold on 
                scatter3(Particle_inside(1),Particle_inside(2),Particle_inside(3),'r','filled')
                cnt=cnt+1;
                point2=[Particle_inside(1)/Pixel_size(1)+0.5,Particle_inside(2)/Pixel_size(2)+0.5,Particle_inside(3)/Pixel_size(3)+0.5];
                point2=[1+( point2(1)-1)/dm,1+( point2(2)-1)/dm,1+( point2(3)-1)/dm];
                ux=interp3(uu{1}{1},point2(1),point2(2),point2(3));
                uy=interp3(uu{1}{2},point2(1),point2(2),point2(3));
                uz=interp3(uu{1}{3},point2(1),point2(2),point2(3));
                U1_xyz=[ux*Pixel_size(1);uy*Pixel_size(2);uz*Pixel_size(3)];
                
                sigmaxx = interp3(Sij{1}{1,1},point2(1),point2(2),point2(3));
                sigmayy = interp3(Sij{1}{2,2},point2(1),point2(2),point2(3));
                sigmazz = interp3(Sij{1}{3,3},point2(1),point2(2),point2(3));
                sigmaxy = interp3(Sij{1}{1,2},point2(1),point2(2),point2(3));
                sigmaxz = interp3(Sij{1}{1,3},point2(1),point2(2),point2(3));
                sigmayz = interp3(Sij{1}{2,3},point2(1),point2(2),point2(3));
                SIGMA1=[sigmaxx,sigmaxy,sigmaxz;sigmaxy,sigmayy,sigmayz;sigmaxz,sigmayz,sigmazz];
                
                Exx = interp3(Eij{1}{1,1},point2(1),point2(2),point2(3));
                Eyy = interp3(Eij{1}{2,2},point2(1),point2(2),point2(3));
                Ezz = interp3(Eij{1}{3,3},point2(1),point2(2),point2(3));
                Exy = interp3(Eij{1}{1,2},point2(1),point2(2),point2(3));
                Exz = interp3(Eij{1}{1,3},point2(1),point2(2),point2(3));
                Eyz = interp3(Eij{1}{2,3},point2(1),point2(2),point2(3));
                E1=[Exx,Exy,Exz;Exy,Eyy,Eyz;Exz,Eyz,Ezz];
                
                [V,D] = eig(E1);
                principal_strains(cnt,:)=diag(D)';
                principal_strains_dir(cnt,:)=reshape(V,[],1)';
%                 
            end
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end