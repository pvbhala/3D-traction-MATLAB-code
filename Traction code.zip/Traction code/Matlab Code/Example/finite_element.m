function finite_element(Result,u_corr,vol00,u_total)

u0=u_corr{1};
[~, m0] = parseImages(vol00,[128 128 64]);
idx = cell(1,3); idx_u0 = cell(1,3);
for i = 1:3
    idx{i} = m0{i}(1):m0{i}(end); 
    idx_u0{i} = linspace(1,size(u0{1},i),length(idx{i})+1); 
    idx_u0{i} = idx_u0{i}(1:length(idx{i}));
end
[m_u0{2}, m_u0{1}, m_u0{3}] = ndgrid(idx_u0{:});
u_corr = cell(1,3);
for i = 1:3, u_corr{i} = mirt3D_mexinterp(u0{i}, m_u0{1}, m_u0{2}, m_u0{3}); end
Disp=Result{3}-Result{4};
Node=Result{4};
for i=1:size(Node,1)
 corr_disp(i,1)=u_total{2}(Node(i,1),Node(i,2),Node(i,3)); 
 corr_disp(i,2)=u_total{1}(Node(i,1),Node(i,2),Node(i,3));
 corr_disp(i,3)=u_total{3}(Node(i,1),Node(i,2),Node(i,3));
end

Node=[0.144*Result{4}(:,2) 0.144*Result{4}(:,1) -0.299*Result{4}(:,3)];
Disp=[0.144*corr_disp(:,2) 0.144*corr_disp(:,1) -0.299*corr_disp(:,3)];

DT = delaunayTriangulation(Node);
K = convexHull(DT);
Boundary_index=[K(:,1);K(:,2);K(:,3)];
Boundary_index=unique(Boundary_index);
Boundary_Points=Node(Boundary_index,:);
X_center=mean(Boundary_Points(:,1));
Y_center=mean(Boundary_Points(:,2));
Z_center=mean(Boundary_Points(:,3));
Center=[X_center,Y_center,Z_center];
E=400;v=0.45;
D=(E/((1+v)*(1-2*v))).*[1-v v v 0 0 0;v 1-v v 0 0 0;v v 1-v 0 0 0;...
    0 0 0 0.5*(1-2*v) 0 0;0 0 0 0 0.5*(1-2*v) 0;...
    0 0 0 0 0 0.5*(1-2*v)];

for i=1:size(DT,1)
    u1=Disp(DT(i,1),1);v1=Disp(DT(i,1),2);w1=Disp(DT(i,1),3);
    u2=Disp(DT(i,2),1);v2=Disp(DT(i,2),2);w2=Disp(DT(i,2),3);
    u3=Disp(DT(i,3),1);v3=Disp(DT(i,3),2);w3=Disp(DT(i,3),3);
    u4=Disp(DT(i,4),1);v4=Disp(DT(i,4),2);w4=Disp(DT(i,4),3);
    
    x1=Node(DT(i,1),1);y1=Node(DT(i,1),2);z1=Node(DT(i,1),3);
    x2=Node(DT(i,2),1);y2=Node(DT(i,2),2);z2=Node(DT(i,2),3);
    x3=Node(DT(i,3),1);y3=Node(DT(i,3),2);z3=Node(DT(i,3),3);
    x4=Node(DT(i,4),1);y4=Node(DT(i,4),2);z4=Node(DT(i,4),3);
    
%     alpha1=det([x2 y2 z2;x3 y3 z3;x4 y4 z4];alpha1=det([x2 y2 z2;x3 y3 z3;x4 y4 z4];
%     alpha2=det([x1 y1 z1;x3 y3 z3;x4 y4 z4];
%     alpha3=det([x1 y1 z1;x2 y2 z2;x4 y4 z4];
%     alpha2=det([x1 y1 z1;x2 y2 z2;x3 y3 z3];
    A=[1 x1 y1 z1 0 0 0 0 0 0 0 0;0 0 0 0 1 x1 y1 z1 0 0 0 0;0 0 0 0 0 0 0 0 1 x1 y1 z1;...
        1 x2 y2 z2 0 0 0 0 0 0 0 0;0 0 0 0 1 x2 y2 z2 0 0 0 0;0 0 0 0 0 0 0 0 1 x2 y2 z2;...
        1 x3 y3 z3 0 0 0 0 0 0 0 0;0 0 0 0 1 x3 y3 z3 0 0 0 0;0 0 0 0 0 0 0 0 1 x3 y3 z3;...
        1 x4 y4 z4 0 0 0 0 0 0 0 0;0 0 0 0 1 x4 y4 z4 0 0 0 0;0 0 0 0 0 0 0 0 1 x4 y4 z4];
    b=[u1 v1 w1 u2 v2 w2 u3 v3 w3 u4 v4 w4]';
    a=A\b;
    Ex=a(2);Ey=a(7);Ez=a(12);Exy=a(3)+a(6);Eyz=a(8)+a(11);Ezx=a(10)+a(4);
    strain{i}=[Ex Ey Ez Exy Eyz Ezx]';
    SS=D*strain{i};
    Sigma{i}=[SS(1),SS(4),SS(6);SS(4),SS(2),SS(5);SS(6),SS(5),SS(3)];
end
count=0;
for j=1:size(K,1)
    H=1;
    m=K(j,:);
    m=sort(m);
    for k=1:size(DT,1)
        n=DT(k,:);
        for ii=1:4
            a=n;
            a(ii)=[];
            a=sort(a);
            if norm(m-a)==0
                count=count+1;
                A=Node(m(1),:);
                B=Node(m(2),:);
                C=Node(m(3),:);
                D=(A+B+C)./3;
                AB=B-A;
                AC=C-A;
                Normal=cross(AB,AC);
                Normal=Normal/norm(Normal);
                Check=A-Center;
                if dot(Check, Normal)<0
                    Normal=-Normal;
                end
                Traction(1:3,count)=Sigma{k}*Normal';
                if dot((Traction(1:3,count))', Normal)<0
                    Traction(4,count)=-norm((Traction(1:3,count))');
                    Traction(1:3,count)=- Traction(1:3,count);
                else
                    Traction(4,count)=norm((Traction(1:3,count))');
                end

                X(1,count)=D(1);
                Y(1,count)=D(2);
                Z(1,count)=D(3);
                H=0;
                break;
            end
        end
        if H==0
            break;
        end
    end
end
U=1;
Quiver_plot(X,Y,Z,Traction(1,:),Traction(2,:),Traction(3,:),Traction,K,Node,1,'[Pa]','Total',U);
end

function varargout = parseImages(varargin)
% pads images and creates meshgrid
I = varargin{1};
sSize = varargin{2};
prePad = sSize/2;
postPad = sSize/2;
sizeI = size(I);
I = padarray(I,prePad,0,'pre');
I = padarray(I,postPad,0,'post');
idx = cell(1,3);
for i = 1:3, idx{i} = (1:1:sizeI(i)) + sSize(i)/2; end
varargout{    1} = I;
varargout{end+1} = idx;

end


function Quiver_plot(x,y,z,u,v,w,traction,Surf,Particle2,layer,title1,title2,U)
figure(14000+100*layer+U)
mags = traction(4,:)';
scale_factor=(1/8)*(max(x)-min(x))/(max(abs(mags)));
% q=quiver3(x,y,z,u*scale_factor,v*scale_factor,w*scale_factor,'AutoScale','off');
q=quiver3(x,y,z,u*scale_factor,v*scale_factor,w*scale_factor,1.0,'MaxHeadSize',5);
%// Get the current colormap
currentColormap = colormap(jet);

%// Now determine the color to make each arrow using a colormap
[~, ~, ind] = histcounts(mags, size(currentColormap, 1));

%// Now map this to a colormap to get RGB
cmap = uint8(ind2rgb(ind(:), currentColormap) * 255);
cmap(:,:,4) = 255;
cmap = permute(repmat(cmap, [1 3 1]), [2 1 3]);

%// We repeat each color 3 times (using 1:3 below) because each arrow has 3 vertices
set(q.Head, ...
    'ColorBinding', 'interpolated', ...
    'ColorData', reshape(cmap(1:3,:,:), [], 4).');   %'

%// We repeat each color 2 times (using 1:2 below) because each tail has 2 vertices
set(q.Tail, ...
    'ColorBinding', 'interpolated', ...
    'ColorData', reshape(cmap(1:2,:,:), [], 4).');
set(q,'linewidth',2);
set(q,'MaxHeadSize',4);
caxis([min(mags), max(mags)])
c=colorbar;
ylabel(c,title2)
hold on
% mmm=trisurf(Surf,Particle2(:,1),Particle2(:,2),Particle2(:,3),'Facecolor','black','FaceAlpha',0.65);
mmm=trisurf(Surf,Particle2(:,1),Particle2(:,2),Particle2(:,3),traction(4,:)');%,'FaceAlpha',0.65);
set(mmm,'EdgeColor','none')
camlight;
% mmm.AmbientStrength = 0.3;
% mmm.DiffuseStrength = 0.8;
% mmm.SpecularStrength = 0.9;
% mmm.SpecularExponent = 25;
% mmm.BackFaceLighting = 'unlit';
axis equal
% daspect([1 1 1])
title(['Layer: ' num2str(layer) title1])
end
