function filter_points=remove_outlier_points_radius(Particle)
x0=mean(Particle(:,1));
y0=mean(Particle(:,2));
z0=mean(Particle(:,3));
Center=[x0 y0 z0];
for i=1:size(Particle,1)
    r(i)=norm(Particle(i,:)-Center);
end
end