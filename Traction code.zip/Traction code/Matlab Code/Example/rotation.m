function [vol00,vol01]=rotation(vol00,vol01)
t=[rotz(10);0 0 0];% can be rotx or roty
t=[t,[0 0 0 1]'];
tform = affine3d(t);
H = imwarp(vol00,tform);
S=size(vol00);
S2=size(H);
P=ceil((S2-S)./2);
Q=S2-S-P;
H(1:Q(1),:,:)=[];H(:,1:Q(2),:)=[];H(:,:,1:Q(3))=[];
H(S(1)+1:S2(1)-Q(1),:,:)=[];H(:,S(2)+1:S2(2)-Q(2),:)=[];H(:,:,S(3)+1:S2(3)-Q(3))=[];
C=imfuse(vol00(:,:,60),vol01(:,:,60),'ColorChannels',[1 2 0]);
figure;image(C)
C=imfuse(H(:,:,60),vol01(:,:,60),'ColorChannels',[1 2 0]);
figure;image(C)
vol00=H;
end