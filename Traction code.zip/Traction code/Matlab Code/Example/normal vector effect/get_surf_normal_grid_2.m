function [Surface Surf2 XYZ Center]=get_surf_normal_grid_2(Surf,Particle,layer)
Boundary_index=[Surf(:,1);Surf(:,2);Surf(:,3)];
Boundary_index=unique(Boundary_index);
Boundary_Points=Particle(Boundary_index,:);
X_center=mean(Boundary_Points(:,1));
Y_center=mean(Boundary_Points(:,2));
Z_center=mean(Boundary_Points(:,3));
Center=[X_center,Y_center,Z_center];
Surf2 = boundary(Boundary_Points(:,1),Boundary_Points(:,2),Boundary_Points(:,3),0);
XYZ=Boundary_Points;
n=5;
for i=1:size(Surf,1)
    A=Particle(Surf(i,1),:);
    B=Particle(Surf(i,2),:);
    C=Particle(Surf(i,3),:);
    AB=B-A;
    AC=C-A;
    Normal=cross(AB,AC);
    Normal=Normal/norm(Normal);
    Check=A-Center;
   if dot(Check, Normal)<0
       Normal=-Normal;
   end
   Surface{1}(i,:)=Normal;
    e1=AB/n;
    e2=AC/n;
    k=0;
    for r=1:n-2
        for t=1:n-r-1
           Point=A+r.*e1+t.*e2;
           In=isintriang(Point,A,B,C);
           if In==1
               k=k+1;
           Surface{2}(i,3*(k-1)+1:3*k)=Point;
           end
       end
   end
%Surface{2}(i,:)=(A+B+C)/3;
Surface{3}(1,i)=10^-12*0.5*norm(cross(AB,AC));
   %%%%%%%%%%%%%%%%%%%%%%%%%%5

%    Vet=[A;B;C];
%    for m=1:21
%        bb(m,:)=Surface{2}(i,3*(m-1)+1:3*m);
%    end
%    hold on
%    plot3(bb(:,1),bb(:,2),bb(:,3),'.b','MarkerSize',10)
%    hold on
%    plot3(Vet(:,1),Vet(:,2),Vet(:,3),'.r','MarkerSize',20)
%    hold on 
%    Centroid=(A+B+C)./3;
%    h=quiver3(Centroid(1),Centroid(2),Centroid(3),10*Normal(1),10*Normal(2),10*Normal(3),'linewidth',1);
end
   figure(400)
plot3(Particle(:,1),Particle(:,2),Particle(:,3),'.','MarkerSize',10)
hold on
hold on
trisurf(Surf,Particle(:,1),Particle(:,2),Particle(:,3))%,'Facecolor','blue','FaceAlpha',0.1*layer*0.05)
axis equal
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

end

function In=isintriang(P,A,B,C)
AB=B-A;
AC=C-A;
AP=P-A;
BC=C-B;
BA=A-B;
BP=P-B;
a1=dot(cross(AB,AC),cross(AB,AP));
a2=dot(cross(AC,AB),cross(AC,AP));
a3=dot(cross(BC,BA),cross(BC,BP));
if abs(a1)<1e-7
    a1=0;
end
if abs(a2)<1e-7
    a2=0;
end
if abs(a3)<1e-7
    a3=0;
end
if a1<0 || a2<0 || a3<0
    In=0;
else
    In=1;
end
end
   