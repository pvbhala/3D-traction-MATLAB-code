function [traction_total, traction_norm, traction_shear, Total_Force,Total_Force_x,Total_Force_y,Total_Force_z, Centroid,principal_strain,Max_shear_strain]=traction(Surface,Eij,Sij,uu,dm,Surf,Particle2,Center,Pixel_size,layer,Surf2,XYZ)
Surf_norm=Surface{1};
Surf_grid=Surface{2};
Surf_area=Surface{3};
neibor = boundary(Surf_grid(:,1),Surf_grid(:,2),Surf_grid(:,3),0);
sizeI = size(Sij{1}{1});
traction_total=zeros(4,size(Surf_norm,1));
idx = cell(1,3);
for i = 1:3, idx{i} = Pixel_size(i):dm*Pixel_size(i):Pixel_size(i)*(dm*(sizeI(i) - 1)+1); end
[m{1}, m{2}, m{3}] =  meshgrid(idx{2},idx{1},idx{3});
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigmax = interp3(m{1},m{2},m{3},Sij{1}{1,1},m{1},m{2},m{3});
sigmay = interp3(m{1},m{2},m{3},Sij{1}{2,2},m{1},m{2},m{3});
sigmaz = interp3(m{1},m{2},m{3},Sij{1}{2,2},m{1},m{2},m{3});
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for r=1:size(Surf_norm,1)
    SIGMA=0;
    E=0;
    U_xyz=0;
    point_center=[0 0 0];
    for t=1:size(Surf_grid(r,:),2)/3
        point=Surf_grid(r,3*(t-1)+1:3*t);
        point2=[point(1)/Pixel_size(1)+0.5,point(2)/Pixel_size(2)+0.5,point(3)/Pixel_size(3)+0.5];
        point2=[1+(point2(1)-1)/dm,1+(point2(2)-1)/dm,1+(point2(3)-1)/dm];
        if abs(point(1)-idx{1}(1))<1e-10 || abs(point(1)-idx{1}(end))<1e-10 || abs(point(2)-idx{2}(1))<1e-10 || abs(point(2)-idx{2}(end))<1e-10 || abs(point(3)-idx{3}(1))<1e-10 || abs(point(3)-idx{3}(end))<1e-10
           if t==1
               SIGMA1=0;
               E1=0;
               U1_xyz=0;
           end
            SIGMA=SIGMA+SIGMA1;
            E=E+E1;
            U_xyz=U_xyz+U1_xyz;
            point_center=point_center+point;
            continue;
        end
%         ux=interp3(m{1},m{2},m{3},uu{1}{1},point(1),point(2),point(3));
%         uy=interp3(m{1},m{2},m{3},uu{1}{2},point(1),point(2),point(3));
%         uz=interp3(m{1},m{2},m{3},uu{1}{3},point(1),point(2),point(3));

        ux=interp3(uu{1}{1},point2(1),point2(2),point2(3));
        uy=interp3(uu{1}{2},point2(1),point2(2),point2(3));
        uz=interp3(uu{1}{3},point2(1),point2(2),point2(3));
        U1_xyz=[ux*Pixel_size(1);uy*Pixel_size(2);uz*Pixel_size(3)];
        U_xyz=U_xyz+U1_xyz;
%         sigmaxx = interp3(m{1},m{2},m{3},Sij{1}{1,1},point(1),point(2),point(3));
%         sigmayy = interp3(m{1},m{2},m{3},Sij{1}{2,2},point(1),point(2),point(3));
%         sigmazz = interp3(m{1},m{2},m{3},Sij{1}{3,3},point(1),point(2),point(3));
%         sigmaxy = interp3(m{1},m{2},m{3},Sij{1}{1,2},point(1),point(2),point(3));
%         sigmaxz = interp3(m{1},m{2},m{3},Sij{1}{1,3},point(1),point(2),point(3));
%         sigmayz = interp3(m{1},m{2},m{3},Sij{1}{2,3},point(1),point(2),point(3));

        sigmaxx = interp3(Sij{1}{1,1},point2(1),point2(2),point2(3));
        sigmayy = interp3(Sij{1}{2,2},point2(1),point2(2),point2(3));
        sigmazz = interp3(Sij{1}{3,3},point2(1),point2(2),point2(3));
        sigmaxy = interp3(Sij{1}{1,2},point2(1),point2(2),point2(3));
        sigmaxz = interp3(Sij{1}{1,3},point2(1),point2(2),point2(3));
        sigmayz = interp3(Sij{1}{2,3},point2(1),point2(2),point2(3));
        SIGMA1=[sigmaxx,sigmaxy,sigmaxz;sigmaxy,sigmayy,sigmayz;sigmaxz,sigmayz,sigmazz];
        SIGMA=SIGMA+SIGMA1;
        
        Exx = interp3(Eij{1}{1,1},point2(1),point2(2),point2(3));
        Eyy = interp3(Eij{1}{2,2},point2(1),point2(2),point2(3));
        Ezz = interp3(Eij{1}{3,3},point2(1),point2(2),point2(3));
        Exy = interp3(Eij{1}{1,2},point2(1),point2(2),point2(3));
        Exz = interp3(Eij{1}{1,3},point2(1),point2(2),point2(3));
        Eyz = interp3(Eij{1}{2,3},point2(1),point2(2),point2(3));
        E1=[Exx,Exy,Exz;Exy,Eyy,Eyz;Exz,Eyz,Ezz];
        E=E+E1;

        point_center=point_center+point;
    end
    [V,D] = eig(E);
    principal_strain(r)=max(abs(reshape(D,[],1)));
    Max_shear_strain(r)=abs(max(reshape(D,[],1))-min(reshape(D,[],1)));
    Disp(1:3,r)=(1/(size(Surf_grid(r,:),2)/3)).*U_xyz;
    traction_total(1:3,r)=(1/(size(Surf_grid(r,:),2)/3)).*(SIGMA*(Surf_norm(r,:))');
    traction_norm(1:3,r)=dot((traction_total(1:3,r))', (Surf_norm(r,:))).*(Surf_norm(r,:))';
    traction_shear(1:3,r)=traction_total(1:3,r)-traction_norm(1:3,r);
    Force(1:3,r)=Surf_area(1,r).*traction_total(1:3,r);
    if point(1)<Center(1)
        Force_x(1:2,r)=[Force(1,r),0];
    else
        Force_x(1:2,r)=[0,Force(1,r)];
    end
    if point(2)<Center(2)
        Force_y(1:2,r)=[Force(2,r),0];
    else
        Force_y(1:2,r)=[0,Force(2,r)];
    end
    if point(3)<Center(3)
        Force_z(1:2,r)=[Force(3,r),0];
    else
        Force_z(1:2,r)=[0,Force(3,r)];
    end
    
    if dot((traction_total(1:3,r))', (Surf_norm(r,:)))<0
        traction_total(4,r)=-norm((traction_total(1:3,r))');
        traction_total(1:3,r)=- traction_total(1:3,r);
        traction_norm(4,r)=-norm((traction_norm(1:3,r))');
        traction_norm(1:3,r)=- traction_norm(1:3,r);
    else
        traction_total(4,r)=norm((traction_total(1:3,r))');
        traction_norm(4,r)=norm((traction_norm(1:3,r))');
    end
    
    if dot((Disp(1:3,r))', (Surf_norm(r,:)))<0
        Disp(4,r)=-norm((Disp(1:3,r))');
        Disp(1:3,r)=- Disp(1:3,r);
    else
        Disp(4,r)=norm((Disp(1:3,r))');
    end
    
%     aaa=[1 0 0];
% if dot((Disp(1:3,r))', aaa)<0
%         Disp(4,r)=-norm((Disp(1:3,r))');
%         Disp(1:3,r)=- Disp(1:3,r);
%     else
%         Disp(4,r)=norm((Disp(1:3,r))');
%     end
    




    traction_shear(4,r)=norm(traction_shear(1:3,r));
    Centroid(:,r)=point_center'./(size(Surf_grid(r,:),2)/3);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%











Total_Force=sum(Force,2);
Total_Force_x=sum(Force_x,2);
Total_Force_y=sum(Force_y,2);
Total_Force_z=sum(Force_z,2);
x=Centroid(1,:);y=Centroid(2,:);z=Centroid(3,:);
u(1,:)=traction_total(1,:);v(1,:)=traction_total(2,:);w(1,:)=traction_total(3,:);
u(2,:)=traction_norm(1,:);v(2,:)=traction_norm(2,:);w(2,:)=traction_norm(3,:);
u(3,:)=traction_shear(1,:);v(3,:)=traction_shear(2,:);w(3,:)=traction_shear(3,:);
u_disp(1,:)=Disp(1,:);v_disp(1,:)=Disp(2,:);w_disp(1,:)=Disp(3,:);
for U=1:3
    if U==1
        Traction=traction_total;title='Total';
    end
    if U==2
        Traction=traction_norm;title='Normal';
    end
    if U==3
        Traction=traction_shear;title='Shear';
    end
    title2='[Pa]';
    Quiver_plot(x,y,z,u(U,:),v(U,:),w(U,:),Traction,Surf,Particle2,layer,title,title2,U)
    %// Compute the magnitude of the vectors
end
title='Displacement';
title2='[um]';
Quiver_plot(x,y,z,u_disp,v_disp,w_disp,Disp,Surf,Particle2,layer,title,title2,1200)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Techplot %%%%%%%%%%
% tdata.Nvar=4;
% tdata.varnames={'x','y','z','traction'};
% tdata.FEsurfaces(1).zonename='Traction field';
% tdata.FEsurfaces(1).x=(XYZ(:,1))';
% tdata.FEsurfaces(1).y=(XYZ(:,2))';
% tdata.FEsurfaces(1).z=(XYZ(:,3))';
% tdata.FEsurfaces(1).order=4;
% tdata.FEsurfaces(1).e2n=Surf2;
% % tdata.FEsurfaces(1).v=[u_disp;v_disp;w_disp];
% tdata.FEsurfaces(1).v=traction(4,:);
% tdata.FEsurfaces(1).varloc=1;
% mat2tecplot(tdata,'displacement field.plt')
end

function Quiver_plot(x,y,z,u,v,w,traction,Surf,Particle2,layer,title1,title2,U)
figure(50000+100*layer+U)
mags = traction(4,:)';

scale_factor=(1/8)*(max(x)-min(x))/(mean(abs(mags)));
% q=quiver3(x,y,z,u*scale_factor,v*scale_factor,w*scale_factor,'AutoScale','off');
q=quiver3(x,y,z,u*scale_factor,v*scale_factor,w*scale_factor,1.5,'MaxHeadSize',5);
%// Get the current colormap
currentColormap = colormap(jet);
currentColormap=colormap(flipud(colormap));
 %aa=linspace(-1150,20,size(currentColormap, 1)+1)';
%// Now determine the color to make each arrow using a colormap
% if U==1200
 [~, ~, ind] = histcounts(mags, size(currentColormap, 1));
% else
%[~, ~, ind] = histcounts(mags,aa);
% end
%// Now map this to a colormap to get RGB
cmap = uint8(ind2rgb(ind(:), currentColormap) * 255);
cmap(:,:,4) = 255;
cmap = permute(repmat(cmap, [1 3 1]), [2 1 3]);

%// We repeat each color 3 times (using 1:3 below) because each arrow has 3 vertices
set(q.Head, ...
    'ColorBinding', 'interpolated', ...
    'ColorData', reshape(cmap(1:3,:,:), [], 4).');   %'

%// We repeat each color 2 times (using 1:2 below) because each tail has 2 vertices
set(q.Tail, ...
    'ColorBinding', 'interpolated', ...
    'ColorData', reshape(cmap(1:2,:,:), [], 4).');
set(q,'linewidth',2);
set(q,'MaxHeadSize',4);

caxis([min(mags), max(mags)])
% if U==1200
 %caxis([-1150 20])
% end
c=colorbar;
%ylabel(c,title2)
 set( c, 'YDir', 'reverse' );
hold on
% mmm=trisurf(Surf,Particle2(:,1),Particle2(:,2),Particle2(:,3),'Facecolor','black','FaceAlpha',0.65);
mmm=trisurf(Surf,Particle2(:,1),Particle2(:,2),Particle2(:,3),traction(4,:)');%,'FaceAlpha',0.65);
set(mmm,'EdgeColor','none')
camlight;
% mmm.AmbientStrength = 0.3;
% mmm.DiffuseStrength = 0.8;
% mmm.SpecularStrength = 0.9;
% mmm.SpecularExponent = 25;
% mmm.BackFaceLighting = 'unlit';
axis equal
% daspect([1 1 1])
title(['Layer: ' num2str(layer) title1])
ER=[title1 num2str(layer)];
savefig(ER)
end