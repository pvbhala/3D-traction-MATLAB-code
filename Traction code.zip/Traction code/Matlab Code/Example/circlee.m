function y=circlee(x)
center=0.5.*size(x);
for i=1:size(x,1)
    for j=1:size(x,2)
        if (i-center(1)-0.5)^2+(j-center(2)-0.5)^2<(11.5/(0.144*2))^2
            y(i,j)=x(i,j);
        else
            y(i,j)=0;
        end
    end
end
end
