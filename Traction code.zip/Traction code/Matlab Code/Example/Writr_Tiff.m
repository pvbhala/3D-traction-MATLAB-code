outputFileName = 'vol00.tif';
for K=1:size(vol00,3)
   imwrite(uint8(vol00(:, :, K)), outputFileName, 'WriteMode', 'append',  'Compression','none');
end