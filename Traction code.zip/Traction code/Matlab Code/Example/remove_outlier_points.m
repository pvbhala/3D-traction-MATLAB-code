function filter_points=remove_outlier_points(Particle)
N=size(Particle,1);
ptCloud = pointCloud(Particle);
Neibor=6;
for i=1:N
    for radius=1:1:100
        [indices,~] = findNeighborsInRadius(ptCloud,Particle(i,:),radius);
        if size(indices,1)>Neibor
            r(i)=radius;
            break;
        end
    end
end
[~,idx,outliers] = deleteoutliers(r);
for j=1:size(idx,2)
    Particle(idx(j),:)=[0 0 0];
% for j=1:size(r,2)
%     if r()
%   
end
Particle( ~any(Particle,2), : ) = [];
filter_points=Particle;
end