function Cand=precise_location(index,image)
tt=size(index,1);
for t=1:tt
    [m,n,p]=ind2sub(size(image),index(t));
    Intensity(t)=image(m,n,p);
end

[Max, ind]=sort(Intensity,'descend');
[i j k]=ind2sub(size(image),index(ind(1)));
Cand(1,:)=[i j k];
% ii=1;
% p=1;
% Check=Max(1);
% while  p==1
%     y=0;
%     [r s t]=ind2sub(size(image),index(ind(ii)));
%     m=[r s t];
%     Check=image(m(1),m(2),m(3));
%     if Check>0.6*Max(1)
%         for j=1:size(Cand,1)
%             if norm(m(1:2)-Cand(j,1:2))<5
%                 if abs(m(3)-Cand(j,3))<10
%                     y=1;
%                     continue;
%                 end
%             end
%         end
%     else
%         y=1;p=0;
%     end
%     if y==0
%         Cand(end+1,:)=m;
%     end
%     if ii==tt
%         p=0;
%     end
%     ii=ii+1;
% end
end



