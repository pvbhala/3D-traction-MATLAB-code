function Tractionerror(u_corr,u_act,traction_total_act)
materialModel = 'linearElastic';
materialProps = [1600, 0.4];
[Fij_act, Sij_act, Eij_act, Uij_act] = fun3DTFM(u_act,1,materialModel,materialProps);
[Fij_corr, Sij_corr, Eij_corr, Uij_corr] = fun3DTFM(u_corr,8,materialModel,materialProps);
layer=1;[x y z]=sphere;
x=12.*x+112*0.144;
y=12.*y+112*0.144;
z=12.*z+80*0.299;
x=reshape(x,[],1);
y=reshape(y,[],1);
z=reshape(z,[],1);
Particle22=[x y z];
Surf12 = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
[Surf_fine12, Particle_fine12]=finer(Surf12,Particle22);
[Surf_fine12, Particle_fine12]=finer(Surf_fine12,Particle_fine12);
[Surface12 Surf2 XYZ Center12]=get_surf_normal_grid(Surf_fine12,Particle_fine12,layer);
Pixel_size=[0.144 0.144 0.299];


A=repmat([112*0.144,112*0.144,80*0.299],size(Surface12{2},1),1);
B=repmat([112*0.144,112*0.144,80*0.299],size(Particle_fine12,1),1);
C=[112*0.144,112*0.144,80*0.299];
radius=8;
Surface10{1}=Surface12{1};Surface10{2}=(radius/12).*(Surface12{2}-A)+A;Surface10{3}=(radius/12)^2.*Surface12{3};
Surf_fine10=Surf_fine12;
Particle_fine10=(radius/12).*(Particle_fine12-B)+B;
Center10=(radius/12).*(Center12-C)+C;

[traction_total_corr, traction_norm_corr, traction_shear_corr, Total_Force_corr, Centroid_corr]=traction(Surface10,Eij_corr,Sij_corr,u_corr,8,Surf_fine10,Particle_fine10,Center10,Pixel_size,1,Surf2,XYZ);
 close all;
% load('traction_total_act.mat')
% [traction_total_act, traction_norm_act, traction_shear_act, Total_Force_act, Centroid_act]=traction(Surface12,Eij_act,Sij_act,u_act,1,Surf_fine12,Particle_fine12,Center12,Pixel_size,2,Surf2,XYZ);
%traction_total_act=-400.*ones(4,size(traction_total_corr,2));
error=abs((traction_total_corr(4,:)-traction_total_act(4,:))./(traction_total_act(4,:))).*100;
save('Error.mat','traction_total_act','traction_total_corr','error','radius');
%save('Error.mat','traction_total_corr');
end