function [averages, principal_strain, Max_shear_strain]=recalculations(u,I0,Pixel_size,dm)
%materialModel = 'linearElastic';
materialModel = 'neohookean';
materialProps = [1.44e+03, 0.4];  % [Young's Modulus, Poisson's Ratio]
%materialProps = [400 0.45];  % [Young's Modulus, Poisson's Ratio]
[Fij, Sij, Eij,Uhat] = fun3DTFM(u, dm, materialModel, materialProps);
% resultsFIDVC{1}=u;resultsFIDVC{2}=dm;resultsFIDVC{3}=Fij;resultsFIDVC{4}=Eij;resultsFIDVC{5}=Sij;
% save('resultsFIDVC.mat','resultsFIDVC');
%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
% Particle1=FirstMaxEstimation(I22{1});
%Particle3=FirstMaxEstimation(I0{2});
Particle2=FirstMaxEstimation(I0{1});
Particle2=[Particle2(:,2),Particle2(:,1),Particle2(:,3)];
Particle2=[Pixel_size(1).*Particle2(:,1),Pixel_size(2).*Particle2(:,2),Pixel_size(3).*Particle2(:,3)];
Particle22=Particle2;
www=4;
for erf=1:www
    Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
    Surf_remove=unique(Surf(:));
    for G=1:size(Surf_remove,1)
        Particle22(Surf_remove(G,1),:)=[0 0 0];
    end
    Particle22( ~any(Particle22,2), : ) = [];
end
for layer=1:1
Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
[Surf_fine, Particle_fine]=finer(Surf,Particle22);
[Surf_fine, Particle_fine]=finer(Surf_fine,Particle_fine);
[Surface Surf2 XYZ Center]=get_surf_normal_grid(Surf_fine,Particle_fine,layer);
% Particle11=AddDispParticle(Particle2,u22);
% Output=ComparePart(Particle1,Particle11,Particle2);
% ResultsParticle=DVC_Particle(Output,Particle3);
% save('ResultsParticle.mat','ResultsParticle');
%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 [traction_total, traction_norm, traction_shear, Total_Force,Total_Force_x,Total_Force_y,Total_Force_z,Centroid,principal_strain,Max_shear_strain]=traction(Surface,Eij,Sij,u,dm,Surf_fine,Particle_fine,Center,Pixel_size,layer+www,Surf2,XYZ);
 Force_layer(1:3,layer)=Total_Force;
Surf_remove=unique(Surf(:));
for G=1:size(Surf_remove,1) 
Particle22(Surf_remove(G,1),:)=[0 0 0];
end
Particle22( ~any(Particle22,2), : ) = [];
end
save('outputs.mat','dm','Eij','Fij','I0','Pixel_size','Sij','u','traction_total', 'traction_norm', 'traction_shear', 'Total_Force','Total_Force_x','Total_Force_y','Total_Force_z');
averages(1,1)=mean(traction_total(4,:));
averages(1,2)=mean(traction_norm(4,:));
averages(1,3)=mean(traction_shear(4,:));
close all
end