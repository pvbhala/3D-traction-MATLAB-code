function [UU]=circle_disp(u)
U1=u{1}{1};
U2=u{1}{2};
U3=u{1}{3};
% E11=E{1}{1,1};
% E22=E{1}{2,2};
% E33=E{1}{3,3};
center=0.5.*size(U1);
for i=1:size(U1,1)
    for j=1:size(U1,2)
        for k=1:size(U1,3)
        if ((i-center(1)-0.5)*2*0.144)^2+((j-center(2)-0.5)*2*0.144)^2+((k-center(3)-0.5)*2*0.299)^2<(10)^2
            UU1(i,j,k)=U1(i,j,k);
            UU2(i,j,k)=U2(i,j,k);
            UU3(i,j,k)=U3(i,j,k);
%              EE11(i,j,k)=E11(i,j,k);
%               EE22(i,j,k)=E22(i,j,k);
%                EE33(i,j,k)=E33(i,j,k);
        else
            UU1(i,j,k)=0;
            UU2(i,j,k)=0;
            UU3(i,j,k)=0;
%              EE11(i,j,k)=0;
%               EE22(i,j,k)=0;
%                EE33(i,j,k)=0;
        end
        end
    end
end
UU{1}{1}=UU1;
UU{1}{2}=UU2;
UU{1}{3}=UU3;
% EE{1}{1,1}=EE11;
% EE{1}{2,2}=EE22;
% EE{1}{3,3}=EE33;
end