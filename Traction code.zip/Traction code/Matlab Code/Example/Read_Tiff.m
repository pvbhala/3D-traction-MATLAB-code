fname = 'after_deconv.tif';
info = imfinfo(fname);
vol00 = [];
numberOfImages = length(info);
for k = 1:numberOfImages
    currentImage = imread(fname, k, 'Info', info);
    vol00(:,:,k) = currentImage;
end 

fname = 'before_deconv.tif';
info = imfinfo(fname);
vol01 = [];
numberOfImages = length(info);
for k = 1:numberOfImages
    currentImage = imread(fname, k, 'Info', info);
    vol01(:,:,k) = currentImage;
end

a=size(vol00);
b=size (vol01);
pix=320;
ref=[pix pix 128];
A=floor((ref-a)/2);
B=ceil((ref-a)/2);
C=floor((ref-b)/2);
D=ceil((ref-b)/2);
vol00=cat(1,vol00,zeros(A(1),a(2),a(3)));
vol00=cat(1,zeros(B(1),a(2),a(3)),vol00);
vol00=cat(2,vol00,zeros(pix,A(2),a(3)));
vol00=cat(2,zeros(pix,B(2),a(3)),vol00);
if A(3)>0
    vol00=cat(3,vol00,zeros(pix,pix,A(3)));
    vol00=cat(3,zeros(pix,pix,B(3)),vol00);
else
    vol00(:,:,1:-A(3))=[];
    vol00(:,:,end+B(3)+1:end)=[];
end
vol01=cat(1,vol01,zeros(C(1),b(2),b(3)));
vol01=cat(1,zeros(D(1),b(2),b(3)),vol01);
vol01=cat(2,vol01,zeros(pix,C(2),b(3)));
vol01=cat(2,zeros(pix,D(2),b(3)),vol01);
if C(3)>0
    vol01=cat(3,vol01,zeros(pix,pix,C(3)));
    vol01=cat(3,zeros(pix,pix,D(3)),vol01);
else
    vol01(:,:,1:-C(3))=[];
    vol01(:,:,end+D(3)+1:end)=[];
end
save('vol00','vol00')
save('vol01','vol01')