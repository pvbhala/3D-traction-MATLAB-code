function vol=prepostpad(varargin)
for i=1:length(varargin)
    sizem(i,:)=size(varargin{i});
end
Size_max=max(sizem);
for j=1:length(varargin)
    prePad = ceil((Size_max - sizem(j,:))/2);
    postPad = floor((Size_max - sizem(j,:))/2);
    a = padarray(varargin{j},prePad,0,'pre');
    a = padarray(a,postPad,0,'post');
    vol{j} = a;
end
end
