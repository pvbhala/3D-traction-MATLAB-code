count=1;
for k=1:dm:dm*(size(Sij{1}{1,1},3)-1)+1
x1=[];y1=[];z1=[];
for i=1:size(Surface{2},1)
    for j=1:size(Surface{2},2)/3
        point=Surface{2}(i,3*(j-1)+1:3*j);
        point=[point(1)/0.131,point(2)/0.131,point(3)/0.2];
        if point(1,3)<k+1 && point(1,3)>k-1
            x1=[x1,((point(1,1)-1)/dm)+1];y1=[y1,((point(1,2)-1)/dm)+1];z1=[z1,((point(1,3)-1)/dm)+1];
        end
    end
end

 g=u{1}{1}(:,:,count);
 figure(count+300)
contourf(g,25);colorbar
hold on
scatter3(y1,x1,z1,'*r','linewidth',4);
count=count+1;
end