function [Surf_fine, Particle_fine]=finer(Surf,Particle22)


Surface=[];
for i=1:size(Surf,1)
    A=Particle22(Surf(i,1),:);
    B=Particle22(Surf(i,2),:);
    C=Particle22(Surf(i,3),:);
    Surface(i,:)=(A+B+C)/3;
end
Particle_fine=Surface;
Surf_fine=boundary(Particle_fine(:,1),Particle_fine(:,2),Particle_fine(:,3),0);


% Surf_fine = boundary(Surface(:,1),Surface(:,2),Surface(:,3),0);
% Boundary_index=[Surf_fine(:,1);Surf_fine(:,2);Surf_fine(:,3)];
% Boundary_index=unique(Boundary_index);
% Particle_fine=Surface(Boundary_index,:);
% Surf_fine=boundary(Particle_fine(:,1),Particle_fine(:,2),Particle_fine(:,3));
end

function In=isintriang(P,A,B,C)
AB=B-A;
AC=C-A;
AP=P-A;
BC=C-B;
BA=A-B;
BP=P-B;
a1=dot(cross(AB,AC),cross(AB,AP));
a2=dot(cross(AC,AB),cross(AC,AP));
a3=dot(cross(BC,BA),cross(BC,BP));
if abs(a1)<1e-7
    a1=0;
end
if abs(a2)<1e-7
    a2=0;
end
if abs(a3)<1e-7
    a3=0;
end
if a1<0 || a2<0 || a3<0
    In=0;
else
    In=1;
end
end
   