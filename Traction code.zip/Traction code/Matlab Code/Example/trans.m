function [u123, vol00, vol01] = trans(vol00,vol01)

    A = vol00;
    B = vol01;
%     A = MTF.*A; B = MTF.*B;
sSize=size(A);
    % run cross-correlation
    A = xCorr3(A,B,sSize);
    
    % find maximum index of the cross-correlaiton
    [~, maxIdx] = max(A(:));
    
    % compute voxel resolution displacements
    [u1, u2, u3] = ind2sub(sSize,maxIdx);
u123(1,:) = [u1 u2 u3] - sSize/2 - 1;
    % gather the 3x3x3 voxel neighborhood around the peak
%     try xCorrPeak = reshape(A(u1 + (-1:1), u2 + (-1:1), u3 + (-1:1)),27,1);        
%         % last squares fitting of the peak to calculate sub-voxel displacements
%         du123 = lsqPolyFit3(xCorrPeak, M{1}, M{2});       
%         
%         %--------------------------------------------------------------------------
%     catch
%         u123(1,:) = nan;
%     end 
%     xCorrPeak = reshape(A(u1 + (-1:1), u2 + (-1:1), u3 + (-1:1)),27,1);
%     
%     % least squares fitting of the peak to calculate sub-voxel displacements
%     du123 = lsqPolyFit3(xCorrPeak, M{1}, M{2});
%     u123(k,:) = [u1 u2 u3] + du123' - (sSize/2) - 1;
    %--------------------------------------------------------------------------
    
    % waitbar calculations (update only every 100 iterations)

    if u123(1)<0
        vol01(1:-u123(1),:,:)=[];
        vol01(size(vol01,1)+1:sSize(1),:,:)=zeros(-u123(1),sSize(2),sSize(3));
    else
        vol01(sSize(1)-u123(1)+1:sSize(1),:,:)=[];
        vol01=cat(1,zeros(u123(1),sSize(2),sSize(3)),vol01);
    end
    if u123(2)<0
        vol01(:,1:-u123(2),:)=[];
        vol01(:,size(vol01,2)+1:sSize(2),:)=zeros(sSize(1),-u123(2),sSize(3));
    else
        vol01(:,sSize(2)-u123(2)+1:sSize(2),:)=[];
        vol01=cat(2,zeros(sSize(1),u123(2),sSize(3)),vol01);
    end
    if u123(3)<0
        vol01(:,:,1:-u123(3))=[];
        vol01(:,:,size(vol01,3)+1:sSize(3))=zeros(sSize(1),sSize(2),-u123(3));
    else
        vol01(:,:,sSize(3)-u123(3)+1:sSize(3))=[];
       vol01=cat(3,zeros(sSize(1),sSize(2),u123(3)),vol01);
    end
end



% theta = -pi/15;
% t = [cos(theta)     -sin(theta)   0 0;sin(theta) cos(theta) 0 0;0 0 1 0;0 0 0 1];
% tform = affine3d(t);
% a = imwarp(vol06,tform);
% a(1:16,:,:)=[];
% a(:,1:16,:)=[];
% a(:,177:193,:)=[];
% a(177:193,:,:)=[];
% C=imfuse(vol00(:,:,78),vol06(:,:,78),'ColorChannels',[1 2 0]);
% image(C)
% C=imfuse(vol00(:,:,78),a(:,:,78),'ColorChannels',[1 2 0]);
% figure;image(C)
%% ========================================================================
function A = xCorr3(A,B,sSize)
% performs fft based cross correlation of A and B (see equation 2)

A = fftn(A,sSize);
B = fftn(B,sSize);
B = conj(B);
A = A.*B;
A = ifftn(A);
A = real(A);
A = fftshift(A);
end

%% ========================================================================
function    duvw = lsqPolyFit3(b, M, trMM)
% LeastSqPoly performs a 3D polynomial fit in the least squares sense
% Solves M*x = b,
% trMM = transpose(M)*M
% trMb = tranpose(M)*b
%
% If you need to generate the coefficients then uncomment the following
% [mx, my, mz] = meshgrid(-1:1,-1:1,-1:1);
% m = [mx(:), my(:), mz(:)];
%
% for i = 1:size(m,1)
%    x = m(i,1); y = m(i,2); z = m(i,3);
%    M1(i,:) = [1,x,y,z,x^2,x*y,x*z,y^2,y*z,z^2];
% end
%
% trMM1 = M'*M;

% b = log(b);
trMb = sum(bsxfun(@times, M, b));

x = trMM\trMb'; %solve for unknown coefficients

A = [x(6), 2*x(5), x(7);
    2*x(8),  x(6) x(9)
    x(9),    x(7), 2*x(10)];

duvw = (A\(-x([2 3 4])));
end

%% ========================================================================
function varargout = generateMTF(sSize)
% MTF functions taken from
% J. Nogueira, A Lecuona, P. A. Rodriguez, J. A. Alfaro, and A. Acosta.
% Limits on the resolution of correlation PIV iterative methods. Practical
% implementation and design of weighting functions. Exp. Fluids,
% 39(2):314{321, July 2005. doi: 10.1007/s00348-005-1017-1

%% equation 4

if prod(single(sSize == 32))
    sSize = sSize(1);
    
    x = cell(1,3);
    [x{1}, x{2}, x{3}] = meshgrid(1:sSize,1:sSize,1:sSize);
    
    nu{1} = 1;
    for i = 1:3
        x{i} = x{i} - sSize/2 - 0.5;
        x{i} = abs(x{i}/sSize);
        nu{1} = nu{1}.*(3*(4*x{i}.^2-4*x{i}+1));
    end
    
    %% equation 5
    [x{1}, x{2}, x{3}] = meshgrid(1:sSize,1:sSize,1:sSize);
    
    for i = 1:3, x{i} = x{i} - sSize/2 - 0.5; end
    
    r = abs(sqrt(x{1}.^2 + x{2}.^2 + x{3}.^2)/sSize);
    nu{2}  = zeros(size(r));
    nu{2}(r < 0.5) = 24/pi*(4*r(r < 0.5).^2-4*r(r < 0.5)+1);
    
    %% equation 6
    [x{1}, x{2}, x{3}] = meshgrid(1:sSize,1:sSize,1:sSize);
    
    nu{3} = 1;
    for i = 1:3,
        x{i} = x{i} - sSize/2 - 0.5;
        x{i} = (x{i}/sSize);
        
        nu{3} = nu{3}.*(12*abs(x{i}).^2 - 12*abs(x{i}) + 3 + ...
            0.15*cos(4*pi*x{i}) + 0.20*cos(6*pi*x{i}) + ...
            0.10*cos(8*pi*x{i}) + 0.05*cos(10*pi*x{i}));
        
    end
    nu{3}(nu{3} < 0) = 0;
    
else
    
    nu{1} = ones(sSize(1),sSize(2),sSize(3));
    nu{2} = nu{1};
    nu{3} = nu{1};
    
end

nu = cellfun(@(x) x/sum(x(:)), nu, 'UniformOutput',0);
nu = cellfun(@sqrt, nu, 'UniformOutput',0);

varargout = nu;

end

%% ========================================================================
function [cc, ccMask] = removeBadCorrelations(I,cc,ccThreshold)
% removes bad correlations.  You can insert your own method here.
minOS = 1;
for i = 1:2
    zeroIdx = I{i} == 0;
    threshold = mean2(I{i}(~zeroIdx));
    I_ = I{i}.*(I{i} < threshold);
    minOS = minOS*sum(I_(:))/sum(~zeroIdx(:));
end
cc = cc - minOS;
cc = cc/(max(I{1}(:))*max(I{2}(:)));
ccMask = double(cc >= ccThreshold);

CC = bwconncomp(~ccMask);
[~,idx] = max(cellfun(@numel,CC.PixelIdxList));
if ~isempty(idx)
    ccMask(CC.PixelIdxList{idx}) = inf;
end
ccMask(cc == 0) = nan;
ccMask(~isfinite(ccMask)) = 0;
cc = cc.*ccMask;

end
%% ========================================================================
function Y=isnoundary(A,abs_max)
Y1=FirstMaxEstimation(A,abs_max);
Y=~Y1;

% for i=1:1
%     A1=[];A2=[];A3=[];A4=[];A5=[];A6=[];A7=[];A8=[];
%     if i==1
%     A1=A(1:16,1:16,1:16);
%     A2=A(1:16,17:32,1:16);
%     A3=A(17:32,1:16,1:16);
%     A4=A(17:32,17:32,1:16);
%     A5=A(1:16,1:16,17:32);
%     A6=A(1:16,17:32,17:32);
%     A7=A(17:32,1:16,17:32);
%     A8=A(17:32,17:32,17:32);
%     end
%     if i==2
%     A1=A(1:12,1:12,1:12);
%     A2=A(1:12,21:32,1:12);
%     A3=A(21:32,1:12,1:12);
%     A4=A(21:32,21:32,1:12);
%     A5=A(1:12,1:12,21:32);
%     A6=A(1:12,21:32,21:32);
%     A7=A(21:32,1:12,21:32);
%     A8=A(21:32,21:32,21:32);
%     end
%     if i==3
%     A1=A(1:8,1:8,1:8);
%     A2=A(1:8,25:32,1:8);
%     A3=A(25:32,1:8,1:8);
%     A4=A(25:32,25:32,1:8);
%     A5=A(1:8,1:8,25:32);
%     A6=A(1:8,25:32,25:32);
%     A7=A(25:32,1:8,25:32);
%     A8=A(25:32,25:32,25:32);
%     end
%     Y1=FirstMaxEstimation(A1,abs_max);Y5=FirstMaxEstimation(A5,abs_max);
%     Y2=FirstMaxEstimation(A2,abs_max);Y6=FirstMaxEstimation(A6,abs_max);
%     Y3=FirstMaxEstimation(A3,abs_max);Y7=FirstMaxEstimation(A7,abs_max);
%     Y4=FirstMaxEstimation(A4,abs_max);Y8=FirstMaxEstimation(A8,abs_max);
%     S=[Y1 Y2 Y3 Y4 Y5 Y6 Y7 Y8];
%     SS=prod(S);
%     if SS==0
%         Y=1;
%         break;
%     end
% end
end

%% ========================================================================
function Y=FirstMaxEstimation(I,abs_max)

B=I>0.2*abs_max;
I1=I.*B;
CC = bwconncomp(I1);
Particle=[];
for r = 1:CC.NumObjects,
    index = CC.PixelIdxList{r};
    Particle=[Particle;precise_location(index,I1)];
end
if CC.NumObjects>=1
    Y=1;
else
    Y=0;
end
end
%% ========================================================================
    
    
    
    
    
    