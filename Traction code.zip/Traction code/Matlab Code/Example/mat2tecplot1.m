tdata=[];
tdata.Nvar=4;
tdata.varnames={'x','y','z','Sigmax'};
tdata.cubes(1).zonename='my IJK volume zone';
tdata.cubes(1).x=m{1};
tdata.cubes(1).y=m{2};
tdata.cubes(1).z=m{3};
tdata.cubes(1).v(1,:,:,:)=Sij{1}{1,1};
% tdata.cubes(1).v(2,:,:,:)=resultsFIDVC{4}{1}{2,2};
mat2tecplot(tdata,'sigmax2.plt')