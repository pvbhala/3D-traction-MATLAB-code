function [Wrap_image, Actual_image, u_total]=Warping_noise(vol00,UU)

SizeI=size(vol00);



u_total{1}=UU{1};
u_total{2}=UU{2};
u_total{3}=UU{3};

[I, m0] = parseImages(vol00,[128 128 64]);
idx = cell(1,3); 
for i = 1:3
    idx{i} = m0{i}(1):m0{i}(end);
end
[m{2}, m{1}, m{3}] = ndgrid(idx{:});
mForward = cellfun(@(x,y) x + y, m, u_total, 'UniformOutput',false);
% interpolate volume based on the deformation
Wrap_image= mirt3D_mexinterp(I,  mForward{1}, mForward{2}, mForward{3});
Actual_image=vol00;
C=imfuse(vol00(:,:,80),Wrap_image(:,:,80),'ColorChannels',[1 2 0]);
image(C)
end


function varargout = parseImages(varargin)
% pads images and creates meshgrid

I = varargin{1};
sSize = varargin{2};

prePad = sSize/2;
postPad = sSize/2;

sizeI = size(I);
I = padarray(I,prePad,0,'pre');
I = padarray(I,postPad,0,'post');

idx = cell(1,3);
for i = 1:3, idx{i} = (1:1:sizeI(i)) + sSize(i)/2; end

varargout{    1} = I;
varargout{end+1} = idx;

end