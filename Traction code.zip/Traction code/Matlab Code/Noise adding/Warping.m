function [Wrap_image, Actual_image,u_total, u_in]=Warping(Img,node,disp,Pixel,model_radius)

Y1=disp(:,1);
Y2=disp(:,2);
Y3=disp(:,3);
xyz=[node,Y1,Y2,Y3];
Abaqus=10^3.*xyz;


% Particle2=FirstMaxEstimation(Img);
% Particle2=[Particle2(:,2),Particle2(:,1),Particle2(:,3)];
% Surf = boundary(Particle2(:,1),Particle2(:,2),Particle2(:,3),0);
% Boundary_index=[Surf(:,1);Surf(:,2);Surf(:,3)];
% Boundary_index=unique(Boundary_index);
% Boundary_Points=Particle2(Boundary_index,:);
% X_center=mean(Particle2(:,1));
% Y_center=mean(Particle2(:,2));
% Z_center=mean(Particle2(:,3));
% Center=[X_center,Y_center,Z_center];
% for S=1:size(Boundary_Points,1);
%     Q(S)=norm(Pixel.*(Boundary_Points(S,:)-Center(1,:)));
% end
% Radius=mean(Q);
SizeI=size(Img);

% for ii=1:SizeI(1)
%     for jj=1:SizeI(2)
%         for kk=1:SizeI(3)
%             if norm(Pixel.*([ii jj kk]-Center(1,:)))>model_radius
%                 Img(ii,jj,kk)=0;
%             end
%         end
%     end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Center_shift=Pixel.*[Center(1),SizeI(1)-Center(2),Center(3)];
% Shift=repmat(Center_shift,size(Abaqus,1),1);
% Abaqus(:,1:3)=Abaqus(:,1:3);%+Shift;
Abaqus(:,5)=-Abaqus(:,5);
i=0;
j=0;
k=0;
FU1= scatteredInterpolant(Abaqus(:,1:3),Abaqus(:,4));
FU2= scatteredInterpolant(Abaqus(:,1:3),Abaqus(:,5));
FU3= scatteredInterpolant(Abaqus(:,1:3),Abaqus(:,6));
for x=1:SizeI(2)/2
%     i=i+1;
    for y=1:SizeI(1)/2
%         j=j+1;
        for z=1:SizeI(3)/2
%             k=k+1;
            a=(x-0.5)*Pixel(1);
            b=(y-0.5)*Pixel(2);
            c=(z-0.5)*Pixel(3);
            if (a^2+b^2+c^2)^0.5>model_radius
                UU1(0.5*SizeI(1)-y+1,x,z)=0;
                UU2(0.5*SizeI(1)-y+1,x,z)=0;
                UU3(0.5*SizeI(1)-y+1,x,z)=0;
                U1(0.5*SizeI(1)-y+1,x,z)=FU1([a b c])/Pixel(1);
                U2(0.5*SizeI(1)-y+1,x,z)=FU2([a b c])/Pixel(2);
                U3(0.5*SizeI(1)-y+1,x,z)=FU3([a b c])/Pixel(3);
            else
                UU1(0.5*SizeI(1)-y+1,x,z)=FU1([a b c])/Pixel(1);
                UU2(0.5*SizeI(1)-y+1,x,z)=FU2([a b c])/Pixel(2);
                UU3(0.5*SizeI(1)-y+1,x,z)=FU3([a b c])/Pixel(3);
                U1(0.5*SizeI(1)-y+1,x,z)=UU1(0.5*SizeI(1)-y+1,x,z);
                U2(0.5*SizeI(1)-y+1,x,z)=UU2(0.5*SizeI(1)-y+1,x,z);
                U3(0.5*SizeI(1)-y+1,x,z)=UU3(0.5*SizeI(1)-y+1,x,z);
            end
            
        end
    end
end

U12=flip(U1,1);
a=cat(1,U1,U12);
b=flip(-a,2);
c=cat(2,b,a);
d=flip(c,3);
U1=cat(3,d,c);

U22=flip(-U2,1);
a=cat(1,U2,U22);
b=flip(a,2);
c=cat(2,b,a);
d=flip(c,3);
U2=cat(3,d,c);

U32=flip(U3,1);
a=cat(1,U3,U32);
b=flip(a,2);
c=cat(2,b,a);
d=flip(-c,3);
U3=cat(3,d,c);

UU12=flip(UU1,1);
a=cat(1,UU1,UU12);
b=flip(-a,2);
c=cat(2,b,a);
d=flip(c,3);
UU1=cat(3,d,c);

UU22=flip(-UU2,1);
a=cat(1,UU2,UU22);
b=flip(a,2);
c=cat(2,b,a);
d=flip(c,3);
UU2=cat(3,d,c);

UU32=flip(UU3,1);
a=cat(1,UU3,UU32);
b=flip(a,2);
c=cat(2,b,a);
d=flip(-c,3);
UU3=cat(3,d,c);

u_total{1}=U1;
u_total{2}=U2;
u_total{3}=U3;
u_in{1}=UU1;
u_in{2}=UU2;
u_in{3}=UU3;
[I, m0] = parseImages(Img,[128 128 64]);
idx = cell(1,3); 
for i = 1:3
    idx{i} = m0{i}(1):m0{i}(end);
end
[m{2}, m{1}, m{3}] = ndgrid(idx{:});
mForward = cellfun(@(x,y) x + y, m, u_total, 'UniformOutput',false);
% interpolate volume based on the deformation
Wrap_image= mirt3D_mexinterp(I,  mForward{1}, mForward{2}, mForward{3});
Actual_image=Img;
C=imfuse(Img(:,:,80),Wrap_image(:,:,80),'ColorChannels',[1 2 0]);
image(C)
end


function varargout = parseImages(varargin)
% pads images and creates meshgrid

I = varargin{1};
sSize = varargin{2};

prePad = sSize/2;
postPad = sSize/2;

sizeI = size(I);
I = padarray(I,prePad,0,'pre');
I = padarray(I,postPad,0,'post');

idx = cell(1,3);
for i = 1:3, idx{i} = (1:1:sizeI(i)) + sSize(i)/2; end

varargout{    1} = I;
varargout{end+1} = idx;

end