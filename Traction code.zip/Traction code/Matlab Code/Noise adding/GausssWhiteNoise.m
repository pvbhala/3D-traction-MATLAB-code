function u_noise=GausssWhiteNoise(u,power)
snr=1;
% snr_dB=10*log10(snr);
a1=reshape(u{1},[],1);
a2=reshape(u{2},[],1);
a3=reshape(u{3},[],1);
A=[a1;a2;a3];
y = awgn(A,snr,power,'linear'); 
b1=reshape(y(1:length(A)/3),size(u{1}));
b2=reshape(y((length(A)/3)+1:2*length(A)/3),size(u{2}));
b3=reshape(y((2*length(A)/3)+1:length(A)),size(u{3}));

u_noise{1}=b1;
u_noise{2}=b2;
u_noise{3}=b3;
save('u_noise.mat','u_noise')
save('snr.mat','snr')
%u_noise{4}=b4;
%Tractionerror(u_noise,u_noise,snr)
end

function Tractionerror(u_corr,u_act,snr)
materialModel = 'linearElastic';
materialProps = [400, 0.45];
% [Fij_act, Sij_act, Eij_act, Uij_act] = fun3DTFM(u_act,1,materialModel,materialProps);
[Fij_corr, Sij_corr, Eij_corr, Uij_corr] = fun3DTFM(u_corr,8,materialModel,materialProps);
layer=1;[x y z]=sphere;
x=10.*x+112*0.144;
y=10.*y+112*0.144;
z=10.*z+80*0.299;
x=reshape(x,[],1);
y=reshape(y,[],1);
z=reshape(z,[],1);
Particle22=[x y z];
Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
[Surf_fine, Particle_fine]=finer(Surf,Particle22);
[Surf_fine, Particle_fine]=finer(Surf_fine,Particle_fine);
[Surface Surf2 XYZ Center]=get_surf_normal_grid(Surf_fine,Particle_fine,layer);
Pixel_size=[0.144 0.144 0.299];
[traction_total_corr, traction_norm_corr, traction_shear_corr, Total_Force_corr, Centroid_corr]=traction(Surface,Sij_corr,u_corr,8,Surf_fine,Particle_fine,Center,Pixel_size,1,Surf2,XYZ);
% % close all;
% [traction_total_act, traction_norm_act, traction_shear_act, Total_Force_act, Centroid_act]=traction(Surface,Sij_act,u_act,1,Surf_fine,Particle_fine,Center,Pixel_size,1,Surf2,XYZ);
% traction_total_act=-50.*ones(4,size(traction_total_corr,2));
% error=abs((traction_total_corr(4,:)-traction_total_act(4,:))./(traction_total_act(4,:))).*100;
% save('Error.mat','traction_total_act','traction_total_corr','error');
save('Error.mat','traction_total_corr','snr');
end