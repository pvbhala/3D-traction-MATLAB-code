function [Power, uu]=power_signal(u,vol00,dm)

SizeI=size(u{1}{1});
Pixel_size=[0.144 0.144 0.299];
Center=[112*0.144 112*0.144 80*0.299];

% Particle2=FirstMaxEstimation(vol00);
% Particle2=[Particle2(:,2),Particle2(:,1),Particle2(:,3)];
% Particle2=[Pixel_size(1).*Particle2(:,1),Pixel_size(2).*Particle2(:,2),Pixel_size(3).*Particle2(:,3)];
% Particle22=Particle2;
% Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);
% [Surf_fine, Particle_fine]=finer(Surf,Particle22);
% [Surf_fine, Particle_fine]=finer(Surf_fine,Particle_fine);

n=0;
uu{1}{1}=zeros(SizeI);
uu{1}{2}=zeros(SizeI);
uu{1}{3}=zeros(SizeI);
for ii=1:SizeI(1)
    for jj=1:SizeI(2)
        for kk=1:SizeI(3)
            x=0.144*(((ii-1)*dm+1)-0.5);
            y=0.144*(((jj-1)*dm+1)-0.5);
            z=0.299*(((kk-1)*dm+1)-0.5);
            point=[x y z];
%             if norm([x y z]-Center)<=12
            %if inpolyhedron(Surf_fine,Particle_fine,point)==1
            if (x^2+y^2+z^2)^0.5>12
                n=n+1;
                a1(1,n)=u{1}{1}(ii,jj,kk);
                a2(1,n)=u{1}{2}(ii,jj,kk);
                a3(1,n)=u{1}{3}(ii,jj,kk);
                uu{1}{1}(ii,jj,kk)=u{1}{1}(ii,jj,kk);
                uu{1}{2}(ii,jj,kk)=u{1}{2}(ii,jj,kk);
                uu{1}{3}(ii,jj,kk)=u{1}{3}(ii,jj,kk);
            end
        end
    end
end

% a1=reshape(u{1}{1},[],1);
b1=mean(a1).*ones(size(a1));
c1=a1-b1;
% a2=reshape(u{1}{2},[],1);
b2=mean(a2).*ones(size(a2));
c2=a2-b2;
% a3=reshape(u{1}{3},[],1);
b3=mean(a3).*ones(size(a3));
c3=a3-b3;
A=[c1;c2;c3];
a=0;
for i=1:length(A)
    a=a+A(i)^2;
end
Power=a/length(A);
end