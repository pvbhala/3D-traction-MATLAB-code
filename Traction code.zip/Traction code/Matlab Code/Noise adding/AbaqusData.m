function Output=AbaqusData(node,disp)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=size(node,1);
U1=disp(1:M);
U2=disp(M+1:2*M);
U3=disp(2*M+1:3*M);
xyz=[node,U1',U2',U3'];
xyz=10^3.*xyz;
scatter3(xyz(:,1)',xyz(:,2)',xyz(:,3)','filled')
hold on
%%%%%%%%%%%% YZ %%%%%%%%%%%%%%%
YZ=xyz;
YZ(:,1)=-YZ(:,1);
YZ(:,4)=-YZ(:,4);
for i=1:size(YZ,1)
    if abs(YZ(i,1))<1e-5
        YZ(i,:)=zeros(1,6);
    end
end
YZ( ~any(YZ,2), : ) = [];
scatter3(YZ(:,1)',YZ(:,2)',YZ(:,3)','filled')
%%%%%%%%%%%% XZ %%%%%%%%%%%%%%%
XZ=xyz;
XZ(:,2)=-XZ(:,2);
XZ(:,5)=-XZ(:,5);
for i=1:size(XZ,1)
    if abs(XZ(i,2))<1e-5
        XZ(i,:)=zeros(1,6);
    end
end
XZ( ~any(XZ,2), : ) = [];
scatter3(XZ(:,1)',XZ(:,2)',XZ(:,3)','filled')
%%%%%%%%%%%% XOY %%%%%%%%%%%%%%%
XOY=xyz;
XOY(:,1)=-XOY(:,1);
XOY(:,2)=-XOY(:,2);
XOY(:,4)=-XOY(:,4);
XOY(:,5)=-XOY(:,5);
for i=1:size(XOY,1)
    if abs(XOY(i,1))<1e-5 || abs(XOY(i,2))<1e-5
        XOY(i,:)=zeros(1,6);
    end
end
XOY( ~any(XOY,2), : ) = [];
scatter3(XOY(:,1)',XOY(:,2)',XOY(:,3)','filled')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a=[xyz;YZ;XZ;XOY];
%%%%%%%%%%%% XY %%%%%%%%%%%%%%%
XY=a;
XY(:,3)=-XY(:,3);
XY(:,6)=-XY(:,6);
for i=1:size(XY,1)
    if abs(XY(i,3))<1e-5
        XY(i,:)=zeros(1,6);
    end
end
XY( ~any(XY,2), : ) = [];
scatter3(XY(:,1)',XY(:,2)',XY(:,3)','filled')
Output=[a;XY];
figure(2)
for o=1:size(Output,1)
    mags(o)=norm(Output(o,4:6));
end
Quiver_plot(Output(:,1),Output(:,2),Output(:,3),Output(:,4),Output(:,5),Output(:,6),mags);

end

function Quiver_plot(x,y,z,u,v,w,mags)
scale_factor=(1/8)*(max(x)-min(x))/(max(abs(mags)));
% q=quiver3(x,y,z,u*scale_factor,v*scale_factor,w*scale_factor,'AutoScale','off');
q=quiver3(x,y,z,u*scale_factor,v*scale_factor,w*scale_factor,1.0,'MaxHeadSize',5);
%// Get the current colormap
currentColormap = colormap(jet);

%// Now determine the color to make each arrow using a colormap
[~, ~, ind] = histcounts(mags, size(currentColormap, 1));

%// Now map this to a colormap to get RGB
cmap = uint8(ind2rgb(ind(:), currentColormap) * 255);
cmap(:,:,4) = 255;
cmap = permute(repmat(cmap, [1 3 1]), [2 1 3]);

%// We repeat each color 3 times (using 1:3 below) because each arrow has 3 vertices
set(q.Head, ...
    'ColorBinding', 'interpolated', ...
    'ColorData', reshape(cmap(1:3,:,:), [], 4).');   %'

%// We repeat each color 2 times (using 1:2 below) because each tail has 2 vertices
set(q.Tail, ...
    'ColorBinding', 'interpolated', ...
    'ColorData', reshape(cmap(1:2,:,:), [], 4).');
set(q,'linewidth',2);
set(q,'MaxHeadSize',4);
caxis([min(mags), max(mags)])
c=colorbar;
end