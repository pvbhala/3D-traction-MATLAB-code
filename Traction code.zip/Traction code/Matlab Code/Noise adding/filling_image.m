function [vol01 vol00]=filling_image (uu)
% vol00=vol0;
% vol01=vol1;
% Particle22=FirstMaxEstimation(vol0);
% for u=1:size(Particle22,1)
%     Intensity(1,u)=vol0(Particle22(u,1),Particle22(u,2),Particle22(u,3));
% end
% MEAN=mean(Intensity);
% 
% Particle2=FirstMaxEstimation(vol1);
% for u=1:size(Particle2,1)
%     Intensity1(1,u)=vol1(Particle2(u,1),Particle2(u,2),Particle2(u,3));
% end
% MEAN1=mean(Intensity1);
% 
% Surf = boundary(Particle22(:,1),Particle22(:,2),Particle22(:,3),0);

vol00=zeros(224,224,160);
vol01=zeros(224,224,160);
pixel=[0.144 0.144 0.299];
u0=uu{1};
[~, m0] = parseImages(vol00,[128 128 64]);
idx = cell(1,3); idx_u0 = cell(1,3);
for i = 1:3
    idx{i} = m0{i}(1):m0{i}(end);
    idx_u0{i} = linspace(1,size(u0{1},i),length(idx{i})+1);
    idx_u0{i} = idx_u0{i}(1:length(idx{i}));
end
[m_u0{2}, m_u0{1}, m_u0{3}] = ndgrid(idx_u0{:});
u = cell(1,3);
for i = 1:3, u{i} = mirt3D_mexinterp(u0{i}, m_u0{1}, m_u0{2}, m_u0{3}); end


% a00=zeros(224,224,160);
% a01=zeros(224,224,160);
U1=u{1};
U2=u{2};
U3=u{3};
SizeI=[224,224,160];
Ind=1:prod(SizeI);
[I, J, K]=ind2sub(SizeI,Ind);
xyz=[I',J',K'];
density=ceil(.004*size(xyz,1));
P=randperm(size(xyz,1),density);
for R=1:size(P,2)
    xyz_sample(R,:)=xyz(P(R),:);
end


sigmax=0.875;
sigmay=0.875;
sigmaz=1.75;
MEAN=200;
for g=1:size(xyz_sample,1)
    point=xyz_sample(g,:);
    Vec=[pixel(1)*(point(1)-112.5),pixel(2)*(point(2)-112.5),pixel(3)*(point(3)-80.5)];
    if norm(Vec)>12%point(1)<11 || point(2)<11 || point(3)<11 || point(1)>246 || point(2)>246 || point(3)>182
        continue;
    end
    uj=U1(point(1),point(2),point(3));
    ui=U2(point(1),point(2),point(3));
    uk=U3(point(1),point(2),point(3));
    
%     if point(1)-3+ceil(ui)<1 || point(2)-3+ceil(uj)<1 || point(3)-4+ceil(uk)<1 || point(1)+3+ceil(ui)>192 || point(2)+3+ceil(uj)>192 || point(3)+4+ceil(uk)>128
%         aaaaaa=0;
%         continue;
%     end
    
    
    for q=-10:10
        for w=-10:10
            for e=-10:10
                vol00(point(1)+q,point(2)+w,point(3)+e)=vol00(point(1)+q,point(2)+w,point(3)+e)+MEAN*exp(-((q^2/(2*sigmax^2))+(w^2/(2*sigmay^2))+(e^2/(2*sigmaz^2))));
                 vol01(point(1)+q+ceil(ui),point(2)+w+ceil(uj),point(3)+e+ceil(uk))=vol01(point(1)+q+ceil(ui),point(2)+w+ceil(uj),point(3)+e+ceil(uk))+MEAN*exp(-(((q+ceil(ui)-ui)^2/(2*sigmax^2))+((w+ceil(uj)-uj)^2/(2*sigmay^2))+((e+ceil(uk)-uk)^2/(2*sigmaz^2))));

            end
        end
    end

end
save('vol00.mat','vol00');
save('vol01.mat','vol01');
end


function varargout = parseImages(varargin)
% pads images and creates meshgrid
I = varargin{1};
sSize = varargin{2};
prePad = sSize/2;
postPad = sSize/2;
sizeI = size(I);
I = padarray(I,prePad,0,'pre');
I = padarray(I,postPad,0,'post');
idx = cell(1,3);
for i = 1:3, idx{i} = (1:1:sizeI(i)) + sSize(i)/2; end
varargout{    1} = I;
varargout{end+1} = idx;

end